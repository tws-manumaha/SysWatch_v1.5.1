import { useState, useEffect, useRef } from 'react';
import { 
  Server, Code, Cpu, Terminal, Folder, FolderOpen, FileText, Play, 
  RefreshCw, Download, Copy, Check, Bell, Gauge, ChevronRight, 
  AlertTriangle, Search, Brain, Radar, Activity, HardDrive, Settings, HelpCircle, ArrowRight
} from 'lucide-react';
import { syswatchFileTree, FileNode } from './codeData';

// Simulated default hosts list
interface SimulatedHost {
  name: string;
  ip: string;
  os: string;
  cpu: number;
  ram: number;
  disk: number;
  status: 'UP' | 'WARNING' | 'DOWN';
  lastSeen: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'bootstrap' | 'explorer' | 'simulator'>('simulator');
  
  // Script and Copying states
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);

  // File Explorer States
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(syswatchFileTree[0].children?.[1] || syswatchFileTree[0]);
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({
    "core": true,
    "modules": true,
    "modules/authentication": false,
    "modules/web_ui": false,
    "modules/web_ui/templates": false,
    "modules/api": false,
    "modules/monitoring_checks": false,
    "modules/alert_engine": false,
    "modules/ai": false,
    "agents": true,
  });

  // Simulator States
  const [hosts, setHosts] = useState<SimulatedHost[]>([
    { name: 'syswatch-prod-srv-01', ip: '10.0.0.4', os: 'Ubuntu 22.04 LTS', cpu: 42, ram: 58, disk: 72, status: 'UP', lastSeen: 'Just now' },
    { name: 'syswatch-prod-db-02', ip: '10.0.0.8', os: 'Rocky Linux 9.2', cpu: 18, ram: 79, disk: 84, status: 'UP', lastSeen: 'Just now' },
    { name: 'syswatch-win-ad-01', ip: '10.0.0.20', os: 'Windows Server 2022', cpu: 31, ram: 45, disk: 61, status: 'UP', lastSeen: 'Just now' },
  ]);
  const [selectedHostIdx, setSelectedHostIdx] = useState<number>(0);
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    '[SYSTEM] SysWatch Core Scheduler Engine v1.1.0 online.',
    '[SYSTEM] Connection pooled with mysql://syswatch@127.0.0.1:3306/syswatch_db successfully.',
    '[SCHEDULER] Registered job: compute_status (Interval: 30s)',
    '[SCHEDULER] Registered job: run_anomaly_detection (Interval: 5m)',
    '[SCHEDULER] Registered job: check_all_certificates (Cron: Daily @ 8:00 AM)',
    '[SCHEDULER] Registered job: send_daily_briefing (Cron: Daily @ 8:00 AM)',
    '[INGEST] Awaiting agent metric reports on port 3000...'
  ]);
  const [alerts, setAlerts] = useState<{ id: number; host: string; rule: string; value: number; time: string; status: 'OPEN' | 'ACKNOWLEDGED' }[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [discoveredIps, setDiscoveredIps] = useState<string[]>([]);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Dynamic system time clock in UTC format
  const [timeString, setTimeString] = useState('');

  // Stats chart reference values (SVG)
  const [cpuHistory, setCpuHistory] = useState<number[]>([30, 45, 38, 55, 42, 50, 41, 48, 52, 42]);

  // Dynamic Real-time clock
  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      const utcYear = now.getUTCFullYear();
      const utcMonth = String(now.getUTCMonth() + 1).padStart(2, '0');
      const utcDay = String(now.getUTCDate()).padStart(2, '0');
      const utcHours = String(now.getUTCHours()).padStart(2, '0');
      const utcMinutes = String(now.getUTCMinutes()).padStart(2, '0');
      const utcSeconds = String(now.getUTCSeconds()).padStart(2, '0');
      setTimeString(`${utcYear}-${utcMonth}-${utcDay} ${utcHours}:${utcMinutes}:${utcSeconds} UTC`);
    };

    updateClock();
    const clockInterval = setInterval(updateClock, 1000);
    return () => clearInterval(clockInterval);
  }, []);

  // Handle auto-simulation logic (updates logs, increments history)
  useEffect(() => {
    const interval = setInterval(() => {
      // Update metrics slightly
      setHosts(prev => prev.map((h, idx) => {
        if (h.status === 'DOWN') return h;
        
        let cpuDelta = Math.floor(Math.random() * 11) - 5;
        let ramDelta = Math.floor(Math.random() * 5) - 2;
        
        let newCpu = Math.max(5, Math.min(99, h.cpu + cpuDelta));
        let newRam = Math.max(10, Math.min(95, h.ram + ramDelta));

        // If high CPU/RAM, check for warning
        let status: 'UP' | 'WARNING' = 'UP';
        if (newCpu > 90 || newRam > 85) {
          status = 'WARNING';
        }

        return { ...h, cpu: newCpu, ram: newRam, status };
      }));

      // Update CPU chart history
      setCpuHistory(prev => {
        const next = [...prev.slice(1)];
        // Use selected host's CPU
        const currentCpu = hosts[selectedHostIdx]?.cpu || 40;
        next.push(currentCpu);
        return next;
      });

      // Periodic random ingestion log
      const randomHost = hosts[Math.floor(Math.random() * hosts.length)];
      if (randomHost.status !== 'DOWN') {
        appendLog(`[INGEST] Received payload from ${randomHost.name} (${randomHost.ip}) - CPU: ${randomHost.cpu}%, RAM: ${randomHost.ram}%, Disk: ${randomHost.disk}%`);
        
        // Random rule evaluations
        if (randomHost.cpu > 90) {
          triggerAlert(randomHost.name, 'High CPU Warning', randomHost.cpu);
        }
        if (randomHost.ram > 85) {
          triggerAlert(randomHost.name, 'Memory Exhaustion Danger', randomHost.ram);
        }
      }
    }, 4000);

    return () => clearInterval(interval);
  }, [hosts, selectedHostIdx]);

  const appendLog = (msg: string) => {
    setTerminalLogs(prev => [...prev.slice(-30), `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  const triggerAlert = (host: string, rule: string, val: number) => {
    // Check if duplicate alert is already open
    const isDuplicate = alerts.some(a => a.host === host && a.rule === rule && a.status === 'OPEN');
    if (isDuplicate) return;

    const newId = Date.now();
    const timeStr = new Date().toLocaleTimeString();
    setAlerts(prev => [
      { id: newId, host, rule, value: val, time: timeStr, status: 'OPEN' },
      ...prev
    ]);
    appendLog(`[ALERT] Threshold breached! ${rule} triggered on ${host}. Resource Value: ${val}%`);
    appendLog(`[NOTIFIER] SMTP dispatch completed to admin@syswatch.local for ${host}`);
    appendLog(`[NOTIFIER] Teams Webhook dispatch completed for alert ID: ${newId}`);
  };

  const handleSliderChange = (type: 'cpu' | 'ram' | 'disk', val: number) => {
    setHosts(prev => prev.map((h, idx) => {
      if (idx !== selectedHostIdx) return h;
      let update = { ...h };
      if (type === 'cpu') update.cpu = val;
      if (type === 'ram') update.ram = val;
      if (type === 'disk') update.disk = val;

      if (update.cpu > 90 || update.ram > 85) {
        update.status = 'WARNING';
      } else {
        update.status = 'UP';
      }
      return update;
    }));

    if (type === 'cpu' && val > 90) {
      triggerAlert(hosts[selectedHostIdx].name, 'High CPU Warning', val);
    }
    if (type === 'ram' && val > 85) {
      triggerAlert(hosts[selectedHostIdx].name, 'Memory Exhaustion Danger', val);
    }
  };

  const ackAlert = (id: number) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, status: 'ACKNOWLEDGED' } : a));
    appendLog(`[ALERT] Admin acknowledged Alert ID ${id}`);
  };

  const resolveAlert = (id: number) => {
    const alertItem = alerts.find(a => a.id === id);
    setAlerts(prev => prev.filter(a => a.id !== id));
    if (alertItem) {
      appendLog(`[ALERT] Resolved Alert ID ${id} on host ${alertItem.host}`);
    }
  };

  const triggerScan = () => {
    if (isScanning) return;
    setIsScanning(true);
    setScanProgress(0);
    setDiscoveredIps([]);
    appendLog(`[DISCOVERY] Spawned fast subnetwork ping sweep execution...`);

    const interval = setInterval(() => {
      setScanProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          setIsScanning(false);
          const found = ['10.0.0.12', '10.0.0.15', '10.0.0.33'];
          setDiscoveredIps(found);
          appendLog(`[DISCOVERY] Ping sweep complete. Discovered ${found.length} active live assets.`);
          found.forEach(ip => {
            appendLog(`[DISCOVERY] Registered discovered IP: ${ip} as hosts system catalog.`);
          });
          
          // Append discovered hosts dynamically to main list
          const discoveredHosts: SimulatedHost[] = [
            { name: 'syswatch-node-12', ip: '10.0.0.12', os: 'Alpine Linux v3.18', cpu: 14, ram: 35, disk: 42, status: 'UP', lastSeen: 'Just now' },
            { name: 'syswatch-node-15', ip: '10.0.0.15', os: 'Debian 12 Buster', cpu: 8, ram: 22, disk: 18, status: 'UP', lastSeen: 'Just now' },
            { name: 'syswatch-node-33', ip: '10.0.0.33', os: 'RedHat EL 9.3', cpu: 25, ram: 48, disk: 69, status: 'UP', lastSeen: 'Just now' }
          ];

          setHosts(prev => {
            const currentIps = prev.map(h => h.ip);
            const toAdd = discoveredHosts.filter(dh => !currentIps.includes(dh.ip));
            return [...prev, ...toAdd];
          });

          return 100;
        }
        
        // Randomly find IP during progress
        if (p % 30 === 0 && p > 0) {
          const fakeIp = `10.0.0.${Math.floor(Math.random() * 250) + 1}`;
          setDiscoveredIps(prev => [...prev, fakeIp]);
          appendLog(`[DISCOVERY] ICMP ECHO_REPLY received from ${fakeIp}`);
        }
        return p + 10;
      });
    }, 300);
  };

  const runAiDiagnostics = () => {
    if (isAnalyzing) return;
    setIsAnalyzing(true);
    setAiAnalysis(null);
    appendLog(`[AI] Transmitting telemetry context variables to DeepSeek endpoint...`);

    setTimeout(() => {
      const activeAlerts = alerts.filter(a => a.host === hosts[selectedHostIdx].name);
      let response = '';

      if (activeAlerts.length > 0) {
        response = `### DeepSeek Root Cause Diagnostics\n\n**Incident Scope**: Anomaly on \`${hosts[selectedHostIdx].name}\`\n**Outage Classification**: Resource Exhaustion State.\n\n**Diagnosis Details**:\n- **Analysis**: The system statistically detected a 3-Sigma variation in metric telemetry. Multiple warning thresholds are breached.\n- **Root Cause**: A rogue background task or leaked server transaction process is saturating thread capabilities.\n\n**Remediation Steps**:\n1. Execute SSH terminal access: \`ssh administrator@${hosts[selectedHostIdx].ip}\`\n2. Inspect execution threads: \`top -o %CPU\` or \`ps aux --sort=-%cpu\`\n3. Kill rogue transaction processes: \`kill -9 <PID>\`\n4. Monitor GC allocations to prevent memory leaks.`;
      } else {
        response = `### DeepSeek Trend Optimization Forecast\n\n**Subject Node**: \`${hosts[selectedHostIdx].name}\` (${hosts[selectedHostIdx].ip})\n**Status**: Healthy (UP)\n\n**Analysis Details**:\n- **Storage Growth**: Disk volume is tracking linearly upwards at 1.2% daily growth.\n- **Exhaustion Prediction**: Storage limits are forecasted to deplete in approximately **14 days**.\n\n**Remediation Suggestion**:\n1. Implement system cleanups or log rotations.\n2. Scale volume capacity constraints by adding a secondary disk array.`;
      }
      
      setAiAnalysis(response);
      setIsAnalyzing(false);
      appendLog(`[AI] Decoded DeepSeek completions callback successfully. Registered new AI Insight.`);
    }, 1800);
  };

  // Copy helper
  const copyToClipboard = (text: string, setCopied: (v: boolean) => void) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Render Directory Tree Node
  const renderTreeNode = (node: FileNode) => {
    const isFolder = node.type === 'folder';
    const isExpanded = expandedFolders[node.path];

    const toggleFolder = () => {
      setExpandedFolders(prev => ({
        ...prev,
        [node.path]: !prev[node.path]
      }));
    };

    const handleFileSelect = () => {
      if (!isFolder) {
        setSelectedFile(node);
      } else {
        toggleFolder();
      }
    };

    return (
      <div key={node.path} className="select-none">
        <div 
          onClick={handleFileSelect}
          className={`flex items-center py-1.5 px-3 rounded-lg text-xs cursor-pointer transition-all ${
            selectedFile?.path === node.path 
              ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20 font-medium' 
              : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
          }`}
          style={{ paddingLeft: `${(node.path.split('/').length) * 12}px` }}
        >
          {isFolder ? (
            isExpanded ? <FolderOpen className="w-3.5 h-3.5 mr-2 text-yellow-500 shrink-0" /> : <Folder className="w-3.5 h-3.5 mr-2 text-yellow-500 shrink-0" />
          ) : (
            <FileText className="w-3.5 h-3.5 mr-2 text-blue-400 shrink-0" />
          )}
          <span className="font-mono truncate">{node.name}</span>
        </div>

        {isFolder && isExpanded && node.children?.map(child => renderTreeNode(child))}
      </div>
    );
  };

  // Calculate dynamic system health index based on metrics and open alerts
  const warningCount = hosts.filter(h => h.status === 'WARNING').length;
  const criticalCount = alerts.filter(a => a.status === 'OPEN').length;
  let healthPercent = 100;
  if (warningCount > 0) healthPercent -= warningCount * 4;
  if (criticalCount > 0) healthPercent -= criticalCount * 12;
  healthPercent = Math.max(58, healthPercent);

  return (
    <div className="flex h-screen w-full bg-slate-950 text-slate-200 font-sans overflow-hidden">
      
      {/* ==================================================== */}
      {/* LEFT SIDEBAR NAVIGATION PANEL (Professional Polish style) */}
      {/* ==================================================== */}
      <aside className="w-64 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0">
        
        {/* Branding header */}
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center shrink-0 shadow-lg shadow-blue-500/30">
              <span className="text-white font-bold font-display text-sm">SW</span>
            </div>
            <div>
              <h1 className="text-sm font-bold tracking-tight text-white flex items-center">
                SysWatch 
                <span className="text-blue-500 font-normal text-[10px] uppercase ml-1.5 px-1 py-0.2 bg-blue-500/10 rounded">v1.1.0</span>
              </h1>
              <p className="text-[10px] text-slate-500 font-medium">Enterprise Monitoring</p>
            </div>
          </div>
        </div>
        
        {/* Navigation lists */}
        <nav className="flex-1 py-6 overflow-y-auto space-y-6 px-4">
          <div className="space-y-1">
            <div className="px-3 text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-2">Monitoring</div>
            
            <button 
              onClick={() => setActiveTab('simulator')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors text-xs font-semibold cursor-pointer ${
                activeTab === 'simulator' 
                  ? 'bg-blue-600/10 border-r-2 border-blue-500 text-blue-400' 
                  : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
              }`}
            >
              <Terminal className="w-4 h-4 shrink-0" />
              <span>Operational Sandbox</span>
            </button>
            
            <button 
              onClick={() => setActiveTab('bootstrap')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors text-xs font-semibold cursor-pointer ${
                activeTab === 'bootstrap' 
                  ? 'bg-blue-600/10 border-r-2 border-blue-500 text-blue-400' 
                  : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
              }`}
            >
              <Activity className="w-4 h-4 shrink-0" />
              <span>Project Generator</span>
            </button>
          </div>

          <div className="space-y-1">
            <div className="px-3 text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-2">Advanced</div>
            
            <button 
              onClick={() => setActiveTab('explorer')}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors text-xs font-semibold cursor-pointer ${
                activeTab === 'explorer' 
                  ? 'bg-blue-600/10 border-r-2 border-blue-500 text-blue-400' 
                  : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
              }`}
            >
              <Code className="w-4 h-4 shrink-0" />
              <span>Code Explorer</span>
            </button>
          </div>
        </nav>

        {/* User profile footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/40">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-blue-600/20 border border-blue-500/20 flex items-center justify-center text-blue-400 font-bold text-xs">
              SA
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-xs font-bold text-white font-mono">sysadmin_prime</p>
              <p className="text-[10px] text-slate-500 truncate font-mono">master-controller-01</p>
            </div>
          </div>
        </div>
      </aside>

      {/* ==================================================== */}
      {/* MAIN VIEWPORT PANEL */}
      {/* ==================================================== */}
      <main className="flex-1 flex flex-col overflow-hidden">
        
        {/* Header Bar */}
        <header className="h-16 border-b border-slate-800 flex items-center justify-between px-8 bg-slate-900/50 shrink-0">
          <div className="flex items-center gap-4">
            <h2 className="text-sm font-medium text-white tracking-tight">
              {activeTab === 'simulator' && "Operational Sandbox"}
              {activeTab === 'bootstrap' && "Enterprise Project Generator"}
              {activeTab === 'explorer' && "System Code Explorer"}
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-[0_0_12px_rgba(16,185,129,0.1)] flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
              AI ENGINE: ONLINE
            </span>
          </div>

          <div className="flex items-center gap-6">
            <div className="text-right">
              <p className="text-[9px] text-slate-500 font-bold uppercase tracking-wider">System Time</p>
              <p className="text-xs font-mono text-slate-300 font-medium">{timeString || 'Loading...'}</p>
            </div>
            <button className="p-2 rounded bg-slate-800/40 hover:bg-slate-800 text-slate-400 transition cursor-pointer relative">
              <Bell className="w-4.5 h-4.5" />
              {alerts.some(a => a.status === 'OPEN') && (
                <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-slate-900 animate-pulse"></span>
              )}
            </button>
          </div>
        </header>

        {/* Dynamic View panels based on activeTab */}
        <div className="flex-1 overflow-y-auto">
          
          {/* ==================================================== */}
          {/* TAB: BOOTSTRAP OVERVIEW (Project Generator) */}
          {/* ==================================================== */}
          {activeTab === 'bootstrap' && (
            <div className="p-8 max-w-5xl mx-auto space-y-8 animate-fadeIn">
              
              {/* Introduction Banner Card */}
              <div className="p-8 bg-gradient-to-br from-blue-950/30 via-slate-900/40 to-slate-900/20 border border-blue-900/20 rounded-2xl relative overflow-hidden shadow-lg shadow-blue-950/10">
                <div className="absolute top-0 right-0 p-8 text-blue-500/5 -mr-12 -mt-12 select-none pointer-events-none">
                  <Server className="w-64 h-64 stroke-[1]" />
                </div>
                <div className="space-y-4 max-w-2xl relative z-10">
                  <h2 className="text-2xl font-display font-bold tracking-tight text-white leading-tight">Instantiate SysWatch v1.1.0 Architecture with One Script</h2>
                  <p className="text-slate-400 text-sm leading-relaxed">
                    We have successfully built and configured <code className="text-blue-400 font-mono text-xs px-1.5 py-0.5 bg-blue-500/10 rounded border border-blue-500/10">build_syswatch.py</code> directly onto the project's root filesystem. Running this script unpacked is all it takes to spawn the entire SysWatch monitoring suite.
                  </p>
                  
                  <div className="flex flex-wrap gap-3 pt-2">
                    <button 
                      onClick={() => copyToClipboard('python build_syswatch.py', setCopiedCmd)}
                      className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded-lg text-xs font-bold text-white transition-all cursor-pointer shadow-md shadow-blue-500/15"
                    >
                      {copiedCmd ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedCmd ? 'Unpack Command Copied!' : 'Copy Unpack Command'}</span>
                    </button>
                    <button 
                      onClick={() => setActiveTab('explorer')}
                      className="flex items-center space-x-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded-lg text-xs font-semibold transition cursor-pointer"
                    >
                      <Code className="w-3.5 h-3.5 text-blue-400" />
                      <span>Explore Source Code Tree</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Deployment Steps Overview */}
              <div className="space-y-4">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest pl-1">Deployment Steps</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-slate-900 border border-slate-800/80 p-6 rounded-xl space-y-3 relative hover:border-slate-700 transition">
                    <div className="p-2 bg-blue-500/10 border border-blue-500/20 rounded-lg text-blue-400 w-fit">
                      <Terminal className="w-4 h-4" />
                    </div>
                    <h4 className="font-bold text-white text-sm">Step 1: Bootstrap</h4>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Execute the python helper script from your main host container terminal to generate the schemas, system directories, and default settings:
                    </p>
                    <pre className="text-[10px] font-mono bg-slate-950 p-3 rounded-lg border border-slate-800 text-blue-400 truncate">python build_syswatch.py</pre>
                  </div>

                  <div className="bg-slate-900 border border-slate-800/80 p-6 rounded-xl space-y-3 relative hover:border-slate-700 transition">
                    <div className="p-2 bg-purple-500/10 border border-purple-500/20 rounded-lg text-purple-400 w-fit">
                      <Settings className="w-4 h-4" />
                    </div>
                    <h4 className="font-bold text-white text-sm">Step 2: Credentials</h4>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Edit the newly-generated environment credentials configuration file <code className="text-slate-300 font-mono text-[11px] bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">.env</code> to supply your live API keys, SMTP credentials, and database keys.
                    </p>
                  </div>

                  <div className="bg-slate-900 border border-slate-800/80 p-6 rounded-xl space-y-3 relative hover:border-slate-700 transition">
                    <div className="p-2 bg-green-500/10 border border-green-500/20 rounded-lg text-green-400 w-fit">
                      <Play className="w-4 h-4" />
                    </div>
                    <h4 className="font-bold text-white text-sm">Step 3: Service Provision</h4>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      Trigger the automated installer utility script <code className="text-slate-300 font-mono text-[11px] bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">install.sh</code> (for Unix) or <code className="text-slate-300 font-mono text-[11px] bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">install.ps1</code> (Windows) to register service daemons.
                    </p>
                  </div>
                </div>
              </div>

              {/* Core Features Checklist */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 space-y-4">
                <h3 className="font-bold text-white text-xs uppercase tracking-widest text-slate-400">Features Checklist & Status</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="flex items-center space-x-3 text-slate-300 bg-slate-950/40 p-3 rounded-lg border border-slate-800/40">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Flask Dashboard & API Engine (MySQL Connection Pools)</span>
                  </div>
                  <div className="flex items-center space-x-3 text-slate-300 bg-slate-950/40 p-3 rounded-lg border border-slate-800/40">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Background Schedulers (Status updates, SSL monitoring)</span>
                  </div>
                  <div className="flex items-center space-x-3 text-slate-300 bg-slate-950/40 p-3 rounded-lg border border-slate-800/40">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Agent Telemetry Loop (Cross-Platform Python Agent)</span>
                  </div>
                  <div className="flex items-center space-x-3 text-slate-300 bg-slate-950/40 p-3 rounded-lg border border-slate-800/40">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>DeepSeek Cognitive diagnostics (API Compliant JSON Prompting)</span>
                  </div>
                  <div className="flex items-center space-x-3 text-slate-300 bg-slate-950/40 p-3 rounded-lg border border-slate-800/40">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Subnetwork Discovery (Multi-threaded Ping sweeps)</span>
                  </div>
                  <div className="flex items-center space-x-3 text-slate-300 bg-slate-950/40 p-3 rounded-lg border border-slate-800/40">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>One-Click Deployments (Systemd service & Task Scheduler setups)</span>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* ==================================================== */}
          {/* TAB: CODE EXPLORER */}
          {/* ==================================================== */}
          {activeTab === 'explorer' && (
            <div className="h-full flex overflow-hidden animate-fadeIn">
              
              {/* Left Sidebar File List */}
              <div className="w-72 border-r border-slate-800 bg-slate-950 flex flex-col overflow-y-auto p-4 space-y-4 shrink-0">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center space-x-2">
                    <Code className="w-4 h-4 text-blue-400" />
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Project Files</span>
                  </div>
                  <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded font-mono">v1.1.0</span>
                </div>

                <div className="space-y-1">
                  {syswatchFileTree.map(node => renderTreeNode(node))}
                </div>
              </div>

              {/* Right Editor Pane */}
              <div className="flex-1 flex flex-col bg-slate-950 overflow-hidden">
                {selectedFile ? (
                  <>
                    {/* Editor Header details */}
                    <div className="bg-slate-900 border-b border-slate-800 px-6 py-3 flex items-center justify-between shrink-0">
                      <div className="flex items-center space-x-2.5">
                        <FileText className="w-4 h-4 text-blue-400" />
                        <span className="font-mono text-xs text-white">{selectedFile.path}</span>
                      </div>

                      <button 
                        onClick={() => copyToClipboard(selectedFile.content || '', setCopiedCode)}
                        className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800 transition cursor-pointer"
                      >
                        {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                        <span>{copiedCode ? 'Copied' : 'Copy Source'}</span>
                      </button>
                    </div>

                    {/* Editor Code Block viewport */}
                    <div className="flex-1 overflow-auto p-6 font-mono text-xs leading-relaxed text-slate-300 bg-slate-950 relative">
                      <pre className="whitespace-pre">
                        {selectedFile.content?.split('\n').map((line, i) => (
                          <div key={i} className="flex">
                            <span className="w-10 text-right pr-4 text-slate-600 select-none font-mono text-[11px]">{i + 1}</span>
                            <span className="text-slate-300 font-mono text-[12px]">{line}</span>
                          </div>
                        ))}
                      </pre>
                    </div>
                  </>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center p-8 space-y-4 text-center">
                    <Code className="w-12 h-12 text-slate-700 stroke-[1.5]" />
                    <div className="space-y-1">
                      <p className="font-bold text-slate-400 text-sm">No File Selected</p>
                      <p className="text-xs text-slate-500 max-w-xs">Pick any source file from the project tree to view its complete production-ready syntax.</p>
                    </div>
                  </div>
                )}
              </div>

            </div>
          )}

          {/* ==================================================== */}
          {/* TAB: OPERATIONAL SIMULATOR (Sandbox) */}
          {/* ==================================================== */}
          {activeTab === 'simulator' && (
            <div className="p-8 max-w-[1600px] mx-auto space-y-8 animate-fadeIn">
              
              {/* Alert Warning strip banner */}
              {alerts.some(a => a.status === 'OPEN') && (
                <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex items-center justify-between shadow-[0_0_15px_rgba(239,68,68,0.05)]">
                  <div className="flex items-center space-x-3 text-red-400">
                    <AlertTriangle className="w-5 h-5 shrink-0 text-red-500 animate-pulse" />
                    <div className="text-xs">
                      <p className="font-bold uppercase tracking-wider">CRITICAL OUTAGE SYSTEM ALERT</p>
                      <p className="text-slate-400 mt-0.5">Threshold metric boundaries have been breached. Review alerts board below.</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Dynamic Stats Row from Professional Polish design theme */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                
                {/* Stat 1: Active Hosts */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-slate-700/60 transition">
                  <p className="text-xs text-slate-500 font-bold uppercase mb-1">Active Hosts</p>
                  <div className="flex items-baseline justify-between">
                    <h3 className="text-3xl font-bold text-white">{hosts.length}</h3>
                    <span className="text-xs text-emerald-400 font-medium font-mono">+{hosts.length - 3} sweeped</span>
                  </div>
                </div>

                {/* Stat 2: System Health */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-slate-700/60 transition">
                  <p className="text-xs text-slate-500 font-bold uppercase mb-1">System Health</p>
                  <div className="flex items-baseline justify-between">
                    <h3 className={`text-3xl font-bold ${healthPercent > 80 ? 'text-emerald-400' : 'text-amber-500'}`}>{healthPercent}%</h3>
                    <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div className={`h-full transition-all duration-500 ${healthPercent > 80 ? 'bg-emerald-500' : 'bg-amber-500'}`} style={{ width: `${healthPercent}%` }}></div>
                    </div>
                  </div>
                </div>

                {/* Stat 3: Open Alerts */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-slate-700/60 transition">
                  <p className="text-xs text-slate-500 font-bold uppercase mb-1">Open Alerts</p>
                  <div className="flex items-baseline justify-between">
                    <h3 className={`text-3xl font-bold ${alerts.filter(a => a.status === 'OPEN').length > 0 ? 'text-amber-500' : 'text-slate-400'}`}>
                      {alerts.filter(a => a.status === 'OPEN').length}
                    </h3>
                    <span className="text-[11px] text-slate-400">
                      {alerts.filter(a => a.status === 'OPEN').length > 0 ? 'Action Required' : 'Nominal State'}
                    </span>
                  </div>
                </div>

                {/* Stat 4: AI Discoveries */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-slate-700/60 transition">
                  <p className="text-xs text-slate-500 font-bold uppercase mb-1">AI Discoveries</p>
                  <div className="flex items-baseline justify-between">
                    <h3 className="text-3xl font-bold text-blue-400">{discoveredIps.length}</h3>
                    <span className="text-xs text-blue-400 font-mono">Auto-scanned</span>
                  </div>
                </div>

              </div>

              {/* Main Workspace Layout Block: Controls + Main Graphs */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* 1. Sandbox Controls (Col-span-4) */}
                <div className="lg:col-span-4 space-y-6">
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-6">
                    <div>
                      <h4 className="font-bold text-white text-xs uppercase tracking-widest text-slate-400">Sandbox Controls</h4>
                      <p className="text-[11px] text-slate-500 mt-1">Stress agent processes, trigger diagnostics, and swept virtual subnets.</p>
                    </div>

                    {/* Target selection */}
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Target Node Selector</label>
                      <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                        {hosts.map((h, i) => (
                          <button 
                            key={h.name}
                            onClick={() => setSelectedHostIdx(i)}
                            className={`w-full p-3 text-left rounded-lg border transition-all text-xs flex justify-between items-center cursor-pointer ${
                              selectedHostIdx === i 
                                ? 'bg-blue-600/15 border-blue-500/40 text-blue-400 font-bold' 
                                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
                            }`}
                          >
                            <div>
                              <p className="font-semibold text-white font-mono text-[11px]">{h.name}</p>
                              <p className="text-[10px] text-slate-500 font-mono mt-0.5">{h.ip}</p>
                            </div>
                            <span className={`w-1.5 h-1.5 rounded-full ${h.status === 'UP' ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Slider parameters */}
                    <div className="space-y-3 pt-2 border-t border-slate-800/80">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Stress Metrics</label>
                      
                      <div className="space-y-4 bg-slate-950/60 border border-slate-800 p-4 rounded-lg">
                        {/* CPU stress */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs font-mono">
                            <span className="text-slate-400">CPU stress</span>
                            <span className="font-bold text-white">{hosts[selectedHostIdx].cpu}%</span>
                          </div>
                          <input 
                            type="range" 
                            min="5" 
                            max="100" 
                            value={hosts[selectedHostIdx].cpu}
                            onChange={(e) => handleSliderChange('cpu', parseInt(e.target.value))}
                            className="w-full accent-blue-500 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer" 
                          />
                        </div>

                        {/* RAM stress */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs font-mono">
                            <span className="text-slate-400">RAM stress</span>
                            <span className="font-bold text-white">{hosts[selectedHostIdx].ram}%</span>
                          </div>
                          <input 
                            type="range" 
                            min="10" 
                            max="100" 
                            value={hosts[selectedHostIdx].ram}
                            onChange={(e) => handleSliderChange('ram', parseInt(e.target.value))}
                            className="w-full accent-blue-500 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer" 
                          />
                        </div>

                        {/* Disk usage */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs font-mono">
                            <span className="text-slate-400">Disk volume</span>
                            <span className="font-bold text-white">{hosts[selectedHostIdx].disk}%</span>
                          </div>
                          <input 
                            type="range" 
                            min="20" 
                            max="100" 
                            value={hosts[selectedHostIdx].disk}
                            onChange={(e) => handleSliderChange('disk', parseInt(e.target.value))}
                            className="w-full accent-blue-500 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer" 
                          />
                        </div>
                      </div>
                    </div>

                    {/* AI Button */}
                    <div className="pt-2 border-t border-slate-800/80">
                      <button 
                        onClick={runAiDiagnostics}
                        disabled={isAnalyzing}
                        className="w-full py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-50 text-white font-bold rounded-lg text-xs shadow-lg shadow-blue-500/10 flex items-center justify-center space-x-2 transition cursor-pointer"
                      >
                        <Brain className="w-4 h-4 shrink-0 text-cyan-300" />
                        <span>{isAnalyzing ? 'Analyzing context...' : 'Run DeepSeek Diagnostics'}</span>
                      </button>
                    </div>

                  </div>

                  {/* Discovery scanning card */}
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
                    <div className="space-y-1">
                      <h4 className="font-bold text-white text-xs uppercase tracking-widest text-slate-400">Network Sweep Scanner</h4>
                      <p className="text-[11px] text-slate-500 leading-relaxed">Scan subnet ranges to locate active agents.</p>
                    </div>

                    <div className="space-y-3">
                      <button 
                        onClick={triggerScan}
                        disabled={isScanning}
                        className="w-full py-2 bg-slate-950 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 text-xs font-semibold rounded-lg flex items-center justify-center space-x-2 transition cursor-pointer"
                      >
                        <Radar className={`w-3.5 h-3.5 text-blue-400 ${isScanning ? 'animate-spin' : ''}`} />
                        <span>{isScanning ? 'Pinging Sweeps...' : 'Trigger Ping Sweep'}</span>
                      </button>

                      {isScanning && (
                        <div className="space-y-1">
                          <div className="w-full bg-slate-950 rounded-full h-1 border border-slate-800">
                            <div className="bg-blue-500 h-1 rounded-full transition-all duration-300" style={{ width: `${scanProgress}%` }}></div>
                          </div>
                          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                            <span>Scanning...</span>
                            <span>{scanProgress}%</span>
                          </div>
                        </div>
                      )}

                      {discoveredIps.length > 0 && !isScanning && (
                        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-[10px] text-slate-400 max-h-24 overflow-y-auto font-mono space-y-1">
                          <p className="text-blue-400 font-bold uppercase mb-1">Located Nodes ({discoveredIps.length}):</p>
                          {discoveredIps.map(ip => <p key={ip} className="font-mono">• IP: {ip} - ECHO_REPLY (Added to table)</p>)}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* 2. Graphs & live telemetry data (Col-span-8) */}
                <div className="lg:col-span-8 space-y-6">
                  
                  {/* Global performance card & SVG graph */}
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col justify-between">
                    <div className="flex justify-between items-center mb-6">
                      <div>
                        <h4 className="font-bold text-white text-xs uppercase tracking-widest text-slate-400">Global Network Telemetry</h4>
                        <p className="text-[11px] text-slate-500 mt-1 font-mono">{hosts[selectedHostIdx].name} • {hosts[selectedHostIdx].ip} • {hosts[selectedHostIdx].os}</p>
                      </div>
                      <span className="bg-slate-950 px-2.5 py-1 rounded border border-slate-800 text-[10px] font-bold text-blue-400 tracking-wider font-mono">REAL TIME STREAM</span>
                    </div>

                    {/* SVG Graph rendering */}
                    <div className="h-44 w-full bg-slate-950 rounded-lg border border-slate-800 p-2 relative flex items-end overflow-hidden">
                      <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                        {/* Grid Lines */}
                        <line x1="0" y1="20" x2="100" y2="20" stroke="#1e293b" strokeWidth="0.5" />
                        <line x1="0" y1="50" x2="100" y2="50" stroke="#1e293b" strokeWidth="0.5" />
                        <line x1="0" y1="80" x2="100" y2="80" stroke="#1e293b" strokeWidth="0.5" />
                        
                        {/* Main CPU Path */}
                        <path 
                          d={`M ${cpuHistory.map((val, idx) => `${(idx / (cpuHistory.length - 1)) * 100},${100 - val}`).join(' L ')}`} 
                          fill="none" 
                          stroke="#3b82f6" 
                          strokeWidth="2.5" 
                          strokeLinecap="round"
                        />

                        {/* Fill area */}
                        <path 
                          d={`M 0,100 L ${cpuHistory.map((val, idx) => `${(idx / (cpuHistory.length - 1)) * 100},${100 - val}`).join(' L ')} L 100,100 Z`} 
                          fill="url(#gradient)" 
                          opacity="0.15" 
                        />

                        <defs>
                          <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" stopColor="#3b82f6" />
                            <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
                          </linearGradient>
                        </defs>
                      </svg>

                      {/* Tracker dot on the latest point */}
                      <div 
                        className="absolute w-2.5 h-2.5 bg-blue-500 rounded-full border border-white animate-pulse"
                        style={{
                          right: '4px',
                          bottom: `${hosts[selectedHostIdx].cpu}%`,
                          transform: 'translateY(50%)'
                        }}
                      ></div>

                      <span className="absolute bottom-2 left-3 text-[10px] text-slate-500 font-semibold font-mono">Stream metrics interval: 4s</span>
                      <span className="absolute top-2 right-3 text-[11px] text-slate-400 font-bold font-mono">{hosts[selectedHostIdx].cpu}% CPU</span>
                    </div>
                  </div>

                  {/* Diagnostic details & Alerts board side-by-side */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    {/* Simulated Active Alerts Queue */}
                    <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col h-72">
                      <h4 className="font-bold text-white text-xs uppercase tracking-widest text-slate-400 mb-4">Simulated Alerts Board</h4>
                      <div className="flex-1 overflow-y-auto pr-1 space-y-3">
                        {alerts.length === 0 ? (
                          <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 py-6">
                            <Bell className="w-8 h-8 stroke-[1.5] text-slate-700 mb-2" />
                            <p className="text-xs">All metric configurations standard.</p>
                          </div>
                        ) : (
                          alerts.map(a => (
                            <div key={a.id} className="p-3.5 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-between text-xs hover:border-slate-700 transition">
                              <div>
                                <div className="flex items-center space-x-2">
                                  <span className="font-bold text-white font-mono">{a.host}</span>
                                  <span className="text-[10px] text-red-400 font-mono">({a.value}%)</span>
                                </div>
                                <p className="text-slate-400 mt-0.5 text-[11px] font-medium">{a.rule}</p>
                              </div>

                              <div className="flex items-center space-x-2">
                                {a.status === 'OPEN' ? (
                                  <button 
                                    onClick={() => ackAlert(a.id)}
                                    className="px-2.5 py-1 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 rounded border border-amber-500/20 text-[10px] font-bold uppercase cursor-pointer transition-colors"
                                  >
                                    Ack
                                  </button>
                                ) : (
                                  <button 
                                    onClick={() => resolveAlert(a.id)}
                                    className="px-2.5 py-1 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 rounded border border-emerald-500/20 text-[10px] font-bold uppercase cursor-pointer transition-colors"
                                  >
                                    Resolve
                                  </button>
                                )}
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>

                    {/* DeepSeek Interactive Panel */}
                    <div className="bg-blue-950/10 border border-blue-500/20 rounded-xl p-6 flex flex-col h-72">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-2">
                          <Brain className="w-4.5 h-4.5 text-blue-400 shrink-0" />
                          <h4 className="font-bold text-blue-400 text-xs uppercase tracking-widest">DeepSeek diagnostics</h4>
                        </div>
                        {aiAnalysis && (
                          <span className="bg-blue-500/10 border border-blue-500/20 text-blue-400 font-bold px-1.5 py-0.5 rounded text-[9px] font-mono">92% CONFIDENCE</span>
                        )}
                      </div>

                      <div className="flex-1 overflow-y-auto pr-1">
                        {aiAnalysis ? (
                          <div className="text-xs space-y-3 leading-relaxed text-slate-300">
                            <div className="bg-slate-950/80 p-3.5 rounded-lg border border-blue-500/10 text-slate-300 whitespace-pre-wrap font-sans text-[11px]">
                              {aiAnalysis}
                            </div>
                            <button 
                              onClick={() => setAiAnalysis(null)}
                              className="text-[10px] font-bold uppercase text-slate-500 hover:text-slate-400 tracking-wider cursor-pointer"
                            >
                              Clear Analysis
                            </button>
                          </div>
                        ) : (
                          <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 py-6 space-y-3">
                            <Brain className="w-8 h-8 stroke-[1.5] text-slate-700" />
                            <div className="space-y-1 max-w-xs">
                              <p className="text-xs font-semibold text-slate-400">DeepSeek Core Analyser Idle</p>
                              <p className="text-[10px] leading-relaxed text-slate-500">Stress a metric or trigger an alert on the left, then click "Run DeepSeek diagnostics" to compile logs and suggest steps.</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                  </div>

                </div>

              </div>

              {/* Recent Events Host lifecycle Table */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                <div className="px-6 py-4 border-b border-slate-800 flex justify-between items-center">
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">Host Lifecycle Status</h4>
                  <span className="text-[10px] text-slate-500 font-mono">Total Monitored Nodes: {hosts.length}</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-950/50 text-[10px] uppercase font-bold text-slate-500 border-b border-slate-800/60">
                        <th className="px-6 py-3.5">Status</th>
                        <th className="px-6 py-3.5">Hostname</th>
                        <th className="px-6 py-3.5">IP Address</th>
                        <th className="px-6 py-3.5">OS Platform</th>
                        <th className="px-6 py-3.5 text-right">CPU / RAM / Disk</th>
                        <th className="px-6 py-3.5 text-right">Sandbox Action</th>
                      </tr>
                    </thead>
                    <tbody className="text-xs divide-y divide-slate-800/40">
                      {hosts.map((h, idx) => {
                        const isSelected = selectedHostIdx === idx;
                        return (
                          <tr key={h.name} className={`hover:bg-slate-800/20 transition ${isSelected ? 'bg-blue-600/5' : ''}`}>
                            <td className="px-6 py-3">
                              <div className="flex items-center gap-2">
                                <span className={`w-1.5 h-1.5 rounded-full ${h.status === 'UP' ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.4)]' : 'bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.4)]'}`}></span>
                                <span className={`font-medium ${h.status === 'UP' ? 'text-emerald-400' : 'text-amber-400'}`}>
                                  {h.status === 'UP' ? 'Healthy' : 'Warning'}
                                </span>
                              </div>
                            </td>
                            <td className="px-6 py-3 font-mono font-bold text-slate-200">{h.name}</td>
                            <td className="px-6 py-3 font-mono text-slate-400">{h.ip}</td>
                            <td className="px-6 py-3 text-slate-400">{h.os}</td>
                            <td className="px-6 py-3 text-right font-mono font-medium">
                              <span className={h.cpu > 90 ? 'text-red-400 font-bold' : ''}>{h.cpu}%</span> /{' '}
                              <span className={h.ram > 85 ? 'text-red-400 font-bold' : ''}>{h.ram}%</span> /{' '}
                              <span>{h.disk}%</span>
                            </td>
                            <td className="px-6 py-3 text-right">
                              <button 
                                onClick={() => setSelectedHostIdx(idx)}
                                className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase transition cursor-pointer ${
                                  isSelected 
                                    ? 'bg-blue-600 text-white font-bold' 
                                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                                }`}
                              >
                                {isSelected ? 'Targeted' : 'Select'}
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Simulated Terminal console stream */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 flex flex-col">
                <div className="flex items-center space-x-2 text-slate-400 border-b border-slate-900 pb-3 mb-3 shrink-0">
                  <Terminal className="w-4 h-4 text-slate-500 shrink-0" />
                  <span className="text-[10px] font-bold uppercase tracking-wider font-mono">Live Ingestion & SysWatch core logs</span>
                </div>
                <div className="font-mono text-[11px] text-slate-400 space-y-1 h-32 overflow-y-auto">
                  {terminalLogs.map((log, i) => (
                    <div key={i} className="leading-relaxed hover:bg-slate-900/30 px-2 py-0.5 rounded truncate font-mono">{log}</div>
                  ))}
                </div>
              </div>

            </div>
          )}

        </div>

      </main>

    </div>
  );
}
