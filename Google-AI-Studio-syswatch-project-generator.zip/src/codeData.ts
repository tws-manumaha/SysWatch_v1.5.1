export interface FileNode {
  name: string;
  type: 'file' | 'folder';
  path: string;
  children?: FileNode[];
  content?: string;
}

export const syswatchFileTree: FileNode[] = [
  {
    name: "core",
    type: "folder",
    path: "core",
    children: [
      {
        name: "__init__.py",
        type: "file",
        path: "core/__init__.py",
        content: `# SysWatch Core Module\n`
      },
      {
        name: "config.py",
        type: "file",
        path: "core/config.py",
        content: `import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "syswatch_super_secret_key_123456")
    DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
    DB_USER = os.getenv("DB_USER", "syswatch")
    DB_PASSWORD = os.getenv("DB_PASSWORD", "syswatch_pass")
    DB_NAME = os.getenv("DB_NAME", "syswatch_db")
    API_KEY = os.getenv("API_KEY", "syswatch_agent_api_key_xyz_9988")
    ADMIN_USER = os.getenv("ADMIN_USER", "admin")
    ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")
    SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
    SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
    SMTP_USER = os.getenv("SMTP_USER", "")
    SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
    TEAMS_WEBHOOK_URL = os.getenv("TEAMS_WEBHOOK_URL", "")
    DISCOVERY_SUBNET = os.getenv("DISCOVERY_SUBNET", "192.168.1.0/24")
    DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")
    DEEPSEEK_API_URL = os.getenv("DEEPSEEK_API_URL", "https://api.deepseek.com/v1")
    DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")`
      },
      {
        name: "database.py",
        type: "file",
        path: "core/database.py",
        content: `import pymysql
from pymysql.cursors import DictCursor
from core.config import Config
import logging

_db_conn = None

def get_db():
    global _db_conn
    if _db_conn is None or not _db_conn.open:
        try:
            _db_conn = pymysql.connect(
                host=Config.DB_HOST,
                user=Config.DB_USER,
                password=Config.DB_PASSWORD,
                database=Config.DB_NAME,
                autocommit=True,
                cursorclass=DictCursor
            )
        except Exception as e:
            logging.error(f"Failed to connect to database: {e}")
            raise e
    return _db_conn

def close_db():
    global _db_conn
    if _db_conn is not None and _db_conn.open:
        _db_conn.close()
        _db_conn = None

def init_db():
    try:
        conn = pymysql.connect(
            host=Config.DB_HOST,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD,
            autocommit=True
        )
        with conn.cursor() as cursor:
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {Config.DB_NAME}")
        conn.close()
    except Exception as e:
        logging.error(f"Could not check or create database: {e}")

    db = get_db()
    try:
        with db.cursor() as cursor:
            cursor.execute("SET FOREIGN_KEY_CHECKS = 0")
            
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS host_groups (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) UNIQUE NOT NULL,
                description TEXT
            ) ENGINE=InnoDB
            """)
            
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS hosts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                hostname VARCHAR(255) UNIQUE NOT NULL,
                ip_address VARCHAR(45),
                status VARCHAR(20) DEFAULT 'UP',
                group_id INT DEFAULT NULL,
                last_seen DATETIME,
                os_platform VARCHAR(100),
                agent_version VARCHAR(20),
                FOREIGN KEY (group_id) REFERENCES host_groups(id) ON DELETE SET NULL
            ) ENGINE=InnoDB
            """)
            
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS metrics (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                host_id INT NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                cpu_percent FLOAT DEFAULT 0.0,
                memory_percent FLOAT DEFAULT 0.0,
                disk_percent FLOAT DEFAULT 0.0,
                network_rx DOUBLE DEFAULT 0.0,
                network_tx DOUBLE DEFAULT 0.0,
                services_status TEXT,
                FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
            ) ENGINE=InnoDB
            """)
            
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS alert_rules (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(150) NOT NULL,
                metric_name VARCHAR(50) NOT NULL,
                operator VARCHAR(5) NOT NULL,
                threshold FLOAT NOT NULL,
                duration INT DEFAULT 0,
                is_enabled TINYINT(1) DEFAULT 1,
                notification_channel VARCHAR(50) DEFAULT 'ALL',
                email_template TEXT
            ) ENGINE=InnoDB
            """)
            
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                host_id INT NOT NULL,
                rule_id INT NOT NULL,
                status VARCHAR(20) DEFAULT 'OPEN',
                triggered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                acknowledged_at DATETIME NULL,
                resolved_at DATETIME NULL,
                value FLOAT DEFAULT 0.0,
                message TEXT,
                FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE,
                FOREIGN KEY (rule_id) REFERENCES alert_rules(id) ON DELETE CASCADE
            ) ENGINE=InnoDB
            """)
            
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(100) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                role VARCHAR(50) DEFAULT 'ADMIN',
                email VARCHAR(150)
            ) ENGINE=InnoDB
            """)
            
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS ssl_certificates (
                id INT AUTO_INCREMENT PRIMARY KEY,
                host_id INT NOT NULL,
                domain VARCHAR(255) UNIQUE NOT NULL,
                expiry_date DATETIME NULL,
                status VARCHAR(20) DEFAULT 'VALID',
                last_checked DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
            ) ENGINE=InnoDB
            """)
            
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS ai_insights (
                id INT AUTO_INCREMENT PRIMARY KEY,
                host_id INT NULL,
                insight_type VARCHAR(50) NOT NULL,
                summary TEXT,
                analysis TEXT,
                generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
            ) ENGINE=InnoDB
            """)
            
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS events (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                host_id INT NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                event_type VARCHAR(100),
                message TEXT,
                severity VARCHAR(20) DEFAULT 'INFO',
                FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
            ) ENGINE=InnoDB
            """)
            
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS network_ranges (
                id INT AUTO_INCREMENT PRIMARY KEY,
                subnet VARCHAR(100) UNIQUE NOT NULL,
                is_active TINYINT(1) DEFAULT 1
            ) ENGINE=InnoDB
            """)
            
            cursor.execute("SET FOREIGN_KEY_CHECKS = 1")
            
            # Seed Default Admin User
            cursor.execute("SELECT COUNT(*) as count FROM users WHERE username = %s", (Config.ADMIN_USER,))
            if cursor.fetchone()['count'] == 0:
                from werkzeug.security import generate_password_hash
                pwd_hash = generate_password_hash(Config.ADMIN_PASSWORD)
                cursor.execute(
                    "INSERT INTO users (username, password_hash, role, email) VALUES (%s, %s, 'ADMIN', 'admin@syswatch.local')",
                    (Config.ADMIN_USER, pwd_hash)
                )
            
            # Seed Default Alert Rules
            cursor.execute("SELECT COUNT(*) as count FROM alert_rules")
            if cursor.fetchone()['count'] == 0:
                default_rules = [
                    ("High CPU Warning", "cpu_percent", ">", 90.0, "The host {hostname} is reporting critical CPU usage at {value}%."),
                    ("Memory Exhaustion Danger", "memory_percent", ">", 85.0, "The host {hostname} is reporting a high memory usage of {value}%."),
                    ("Out of Disk Space", "disk_percent", ">", 95.0, "The host {hostname} is reporting critical disk capacity exhaustion at {value}%.")
                ]
                for name, metric, op, threshold, template in default_rules:
                    cursor.execute(
                        "INSERT INTO alert_rules (name, metric_name, operator, threshold, email_template) VALUES (%s, %s, %s, %s, %s)",
                        (name, metric, op, threshold, template)
                    )
                    
            logging.info("Database schemas and seed resources loaded successfully.")
    except Exception as e:
        logging.error(f"Database schema initialization failed: {e}")`
      },
      {
        name: "scheduler.py",
        type: "file",
        path: "core/scheduler.py",
        content: `import logging
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

scheduler = BackgroundScheduler()

def start_scheduler(app):
    if not scheduler.running:
        from modules.monitoring_checks.status_updater import compute_status
        from modules.monitoring_checks.ssl_expiry import check_all_certificates
        from modules.ai.anomaly import run_anomaly_detection, run_predictions, send_daily_briefing
        from modules.alert_engine.auto_resolve import auto_resolve_stale_alerts

        def run_with_context(func):
            def wrapper():
                with app.app_context():
                    try:
                        func()
                    except Exception as e:
                        logging.error(f"Scheduler job {func.__name__} failed: {e}")
            return wrapper

        scheduler.add_job(run_with_context(compute_status), 'interval', seconds=30, id='status_sync')
        scheduler.add_job(run_with_context(check_all_certificates), CronTrigger(hour=8, minute=0), id='ssl_sync')
        scheduler.add_job(run_with_context(run_anomaly_detection), 'interval', minutes=5, id='anomaly_detection')
        scheduler.add_job(run_with_context(run_predictions), 'interval', hours=6, id='predictive_run')
        scheduler.add_job(run_with_context(auto_resolve_stale_alerts), 'interval', minutes=10, id='auto_resolve')
        scheduler.add_job(run_with_context(send_daily_briefing), CronTrigger(hour=8, minute=0), id='daily_brief')

        scheduler.start()
        logging.info("APScheduler back-end jobs registered and started successfully.")

def shutdown_scheduler():
    if scheduler.running:
        scheduler.shutdown()
        logging.info("APScheduler monitoring jobs shut down safely.")`
      },
      {
        name: "app.py",
        type: "file",
        path: "core/app.py",
        content: `from flask import Flask
from flask_login import LoginManager
from core.config import Config
from core.database import init_db
from core.scheduler import start_scheduler
import logging

login_manager = LoginManager()
login_manager.login_view = 'auth_bp.login'

def create_app():
    app = Flask(__name__, template_folder='../modules/web_ui/templates', static_folder='../modules/web_ui/static')
    app.config.from_object(Config)

    logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')

    init_db()
    login_manager.init_app(app)

    from modules.authentication.routes import auth_bp
    from modules.web_ui.routes import ui_bp
    from modules.api.routes import api_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(ui_bp)
    app.register_blueprint(api_bp, url_prefix='/api')

    import os
    if os.environ.get("WERKZEUG_RUN_MAIN") == "true" or not app.debug:
        start_scheduler(app)

    return app`
      }
    ]
  },
  {
    name: "modules",
    type: "folder",
    path: "modules",
    children: [
      {
        name: "authentication",
        type: "folder",
        path: "modules/authentication",
        children: [
          {
            name: "models.py",
            type: "file",
            path: "modules/authentication/models.py",
            content: `from flask_login import UserMixin
from core.database import get_db
import pymysql

class User(UserMixin):
    def __init__(self, user_id, username, role, email):
        self.id = user_id
        self.username = username
        self.role = role
        self.email = email

    @staticmethod
    def get(user_id):
        conn = get_db()
        try:
            with conn.cursor(pymysql.cursors.DictCursor) as cursor:
                cursor.execute("SELECT id, username, role, email FROM users WHERE id = %s", (user_id,))
                user_data = cursor.fetchone()
                if user_data:
                    return User(user_data['id'], user_data['username'], user_data['role'], user_data['email'])
        except Exception as e:
            pass
        return None

from core.app import login_manager
@login_manager.user_loader
def load_user(user_id):
    return User.get(int(user_id))`
          },
          {
            name: "routes.py",
            type: "file",
            path: "modules/authentication/routes.py",
            content: `from flask import Blueprint, request, render_template, redirect, url_for, flash, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from core.database import get_db
from modules.authentication.models import User
import pymysql

auth_bp = Blueprint('auth_bp', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('ui_bp.dashboard'))

    if request.method == 'POST':
        if request.is_json:
            data = request.get_json()
            username = data.get('username')
            password = data.get('password')
        else:
            username = request.form.get('username')
            password = request.form.get('password')

        conn = get_db()
        try:
            with conn.cursor(pymysql.cursors.DictCursor) as cursor:
                cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
                user_data = cursor.fetchone()
                if user_data and check_password_hash(user_data['password_hash'], password):
                    user = User(user_data['id'], user_data['username'], user_data['role'], user_data['email'])
                    login_user(user)
                    if request.is_json:
                        return jsonify({"status": "success", "message": "Sign-in successful."})
                    return redirect(url_for('ui_bp.dashboard'))
        except Exception as e:
            if request.is_json:
                return jsonify({"status": "error", "message": str(e)}), 500
            flash(f"Database connectivity failed: {e}", "danger")

        if request.is_json:
            return jsonify({"status": "error", "message": "Invalid password credentials."}), 401
        flash("Invalid username or security credentials", "danger")

    return render_template('login.html')`
          }
        ]
      },
      {
        name: "web_ui",
        type: "folder",
        path: "modules/web_ui",
        children: [
          {
            name: "routes.py",
            type: "file",
            path: "modules/web_ui/routes.py",
            content: `from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required, current_user

ui_bp = Blueprint('ui_bp', __name__)

@ui_bp.route('/')
@login_required
def dashboard():
    return render_template('dashboard.html')`
          },
          {
            name: "templates",
            type: "folder",
            path: "modules/web_ui/templates",
            children: [
              {
                name: "login.html",
                type: "file",
                path: "modules/web_ui/templates/login.html",
                content: `<!-- Login Gateway Styled with Tailwind CDN -->
<!DOCTYPE html>
<html lang="en">
...
</html>`
              },
              {
                name: "dashboard.html",
                type: "file",
                path: "modules/web_ui/templates/dashboard.html",
                content: `<!-- Full Dynamic Single Page Dashboard UI -->
<!DOCTYPE html>
<html lang="en">
...
</html>`
              }
            ]
          }
        ]
      },
      {
        name: "api",
        type: "folder",
        path: "modules/api",
        children: [
          {
            name: "routes.py",
            type: "file",
            path: "modules/api/routes.py",
            content: `from flask import Blueprint, request, jsonify
from core.database import get_db
from core.config import Config
from modules.alert_engine.lifecycle import evaluate_alerts
import pymysql
import json

api_bp = Blueprint('api_bp', __name__)`
          }
        ]
      },
      {
        name: "monitoring_checks",
        type: "folder",
        path: "modules/monitoring_checks",
        children: [
          {
            name: "status_updater.py",
            type: "file",
            path: "modules/monitoring_checks/status_updater.py",
            content: `from core.database import get_db
import logging

def compute_status():
    conn = get_db()
    try:
        with conn.cursor() as cursor:
            # Shift status to DOWN after 120s of silence
            cursor.execute("""
            UPDATE hosts 
            SET status = 'DOWN' 
            WHERE last_seen IS NOT NULL AND last_seen < NOW() - INTERVAL 120 SECOND AND status != 'DOWN'
            """)
        conn.commit()
    except Exception as e:
        logging.error(f"Failed to process host monitoring statuses: {e}")`
          },
          {
            name: "ssl_expiry.py",
            type: "file",
            path: "modules/monitoring_checks/ssl_expiry.py",
            content: `import socket
import ssl
from datetime import datetime
from core.database import get_db
import logging

def check_all_certificates():
    # Extracts socket domains and checks remaining expiry days...
    pass`
          }
        ]
      },
      {
        name: "alert_engine",
        type: "folder",
        path: "modules/alert_engine",
        children: [
          {
            name: "lifecycle.py",
            type: "file",
            path: "modules/alert_engine/lifecycle.py",
            content: `from core.database import get_db
from modules.alert_engine.notifiers import send_email, send_teams_alert
import logging

def evaluate_alerts(host_id, hostname, metrics):
    # Evaluates metrics against threshold constraints and logs active alarms
    pass`
          },
          {
            name: "auto_resolve.py",
            type: "file",
            path: "modules/alert_engine/auto_resolve.py",
            content: `from core.database import get_db
import logging

def auto_resolve_stale_alerts():
    # Polls metrics and auto-resolves fixed incidents
    pass`
          },
          {
            name: "notifiers.py",
            type: "file",
            path: "modules/alert_engine/notifiers.py",
            content: `import smtplib
from email.mime.text import MIMEText
import requests
from core.config import Config
import logging

def send_email(subject, body, to_email=None):
    # SMTP logic
    pass

def send_teams_alert(title, text):
    # Webhook logic
    pass`
          }
        ]
      },
      {
        name: "ai",
        type: "folder",
        path: "modules/ai",
        children: [
          {
            name: "anomaly.py",
            type: "file",
            path: "modules/ai/anomaly.py",
            content: `from core.database import get_db
from modules.ai.deepseek import analyze_with_deepseek
import json
import logging

def run_anomaly_detection():
    # Performs Sigma-3 statistical bounds check
    pass`
          },
          {
            name: "deepseek.py",
            type: "file",
            path: "modules/ai/deepseek.py",
            content: `import requests
import json
from core.config import Config
import logging

def analyze_with_deepseek(analysis_type, context):
    # Connects to Deepseek API endpoints...
    pass`
          }
        ]
      }
    ]
  },
  {
    name: "agents",
    type: "folder",
    path: "agents",
    children: [
      {
        name: "client.py",
        type: "file",
        path: "agents/client.py",
        content: `import os
import sys
import time
import socket
import requests
import psutil
from dotenv import load_dotenv

load_dotenv()

SERVER_URL = os.getenv("SERVER_URL", "http://127.0.0.1:3000")
API_KEY = os.getenv("API_KEY", "syswatch_agent_api_key_xyz_9988")`
      }
    ]
  },
  {
    name: "install.sh",
    type: "file",
    path: "install.sh",
    content: `#!/bin/bash
# Debian / Ubuntu and RHEL production installer shell
# installs python3-venv, nginx, mariadb...
`
  },
  {
    name: "install.ps1",
    type: "file",
    path: "install.ps1",
    content: `# Windows Powershell script
# Installs Chocolatey and requirements...
`
  },
  {
    name: "wsgi.py",
    type: "file",
    path: "wsgi.py",
    content: `from core.app import create_app

app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000)`
  },
  {
    name: "requirements.txt",
    type: "file",
    path: "requirements.txt",
    content: `flask>=3.0.0
flask-login>=0.6.3
pymysql>=1.1.0
python-dotenv>=1.0.0
requests>=2.31.0
psutil>=5.9.8
gunicorn>=21.2.0
apscheduler>=3.10.4
pyOpenSSL>=24.0.0`
  },
  {
    name: "README.md",
    type: "file",
    path: "README.md",
    content: `# SysWatch v1.1.0\n\nOpen‑source infrastructure monitoring platform...`
  },
  {
    name: "LICENSE.txt",
    type: "file",
    path: "LICENSE.txt",
    content: `MIT License\n\nCopyright (c) 2026 SysWatch Team...`
  }
];
