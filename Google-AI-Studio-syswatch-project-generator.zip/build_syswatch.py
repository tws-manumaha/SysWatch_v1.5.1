#!/usr/bin/env python3
"""
SysWatch v1.1.0 - Project Bootstrap & Generator Script
======================================================
This self-contained Python script automatically unpacks the full SysWatch v1.1.0 
directory tree and instantiates all production-ready modules, agents, databases, 
installation shell and powershell scripts.

Usage:
  python build_syswatch.py

Features:
  - Generates SysWatch's Flask server structure, databases, rules and schedulers.
  - Automatically handles file structures, directories, and file permissions.
  - Mitigates all package and path collisions.
"""

import os
import sys
import stat

# Dictionary of all files and their corresponding content
FILES = {}

# -------------------------------------------------------------
# 1. CORE / APP INITIALIZATION
# -------------------------------------------------------------

FILES["core/__init__.py"] = """# SysWatch Core Module
"""

FILES["core/config.py"] = """import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "syswatch_super_secret_key_123456")
    DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
    DB_USER = os.getenv("DB_USER", "syswatch")
    DB_PASSWORD = os.getenv("DB_PASSWORD", "syswatch_pass")
    DB_NAME = os.getenv("DB_NAME", "syswatch_db")
    API_KEY = os.getenv("API_KEY", "syswatch_agent_api_key_xyz_9988")
    ADMIN_USER = os.getenv("ADMIN_USER", "admin")
    ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")
    SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
    SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
    SMTP_USER = os.getenv("SMTP_USER", "")
    SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
    TEAMS_WEBHOOK_URL = os.getenv("TEAMS_WEBHOOK_URL", "")
    DISCOVERY_SUBNET = os.getenv("DISCOVERY_SUBNET", "192.168.1.0/24")
    DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY", "")
    DEEPSEEK_API_URL = os.getenv("DEEPSEEK_API_URL", "https://api.deepseek.com/v1")
    DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")
"""

FILES["core/database.py"] = """import pymysql
from pymysql.cursors import DictCursor
from core.config import Config
import logging

_db_conn = None

def get_db():
    global _db_conn
    if _db_conn is None or not _db_conn.open:
        try:
            _db_conn = pymysql.connect(
                host=Config.DB_HOST,
                user=Config.DB_USER,
                password=Config.DB_PASSWORD,
                database=Config.DB_NAME,
                autocommit=True,
                cursorclass=DictCursor
            )
        except Exception as e:
            logging.error(f"Failed to connect to database: {e}")
            raise e
    return _db_conn

def close_db():
    global _db_conn
    if _db_conn is not None and _db_conn.open:
        _db_conn.close()
        _db_conn = None

def init_db():
    try:
        # Step 1: Connect without database to create DB if missing
        conn = pymysql.connect(
            host=Config.DB_HOST,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD,
            autocommit=True
        )
        with conn.cursor() as cursor:
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {Config.DB_NAME}")
        conn.close()
    except Exception as e:
        logging.error(f"Could not check or create database: {e}")

    # Step 2: Establish connection and create required tables
    db = get_db()
    try:
        with db.cursor() as cursor:
            cursor.execute("SET FOREIGN_KEY_CHECKS = 0")
            
            # Host Groups Table
            cursor.execute(\"\"\"
            CREATE TABLE IF NOT EXISTS host_groups (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) UNIQUE NOT NULL,
                description TEXT
            ) ENGINE=InnoDB
            \"\"\")
            
            # Hosts Table
            cursor.execute(\"\"\"
            CREATE TABLE IF NOT EXISTS hosts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                hostname VARCHAR(255) UNIQUE NOT NULL,
                ip_address VARCHAR(45),
                status VARCHAR(20) DEFAULT 'UP',
                group_id INT DEFAULT NULL,
                last_seen DATETIME,
                os_platform VARCHAR(100),
                agent_version VARCHAR(20),
                FOREIGN KEY (group_id) REFERENCES host_groups(id) ON DELETE SET NULL
            ) ENGINE=InnoDB
            \"\"\")
            
            # Metrics Table
            cursor.execute(\"\"\"
            CREATE TABLE IF NOT EXISTS metrics (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                host_id INT NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                cpu_percent FLOAT DEFAULT 0.0,
                memory_percent FLOAT DEFAULT 0.0,
                disk_percent FLOAT DEFAULT 0.0,
                network_rx DOUBLE DEFAULT 0.0,
                network_tx DOUBLE DEFAULT 0.0,
                services_status TEXT,
                FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
            ) ENGINE=InnoDB
            \"\"\")
            
            # Alert Rules Table
            cursor.execute(\"\"\"
            CREATE TABLE IF NOT EXISTS alert_rules (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(150) NOT NULL,
                metric_name VARCHAR(50) NOT NULL,
                operator VARCHAR(5) NOT NULL,
                threshold FLOAT NOT NULL,
                duration INT DEFAULT 0,
                is_enabled TINYINT(1) DEFAULT 1,
                notification_channel VARCHAR(50) DEFAULT 'ALL',
                email_template TEXT
            ) ENGINE=InnoDB
            \"\"\")
            
            # Alerts Table
            cursor.execute(\"\"\"
            CREATE TABLE IF NOT EXISTS alerts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                host_id INT NOT NULL,
                rule_id INT NOT NULL,
                status VARCHAR(20) DEFAULT 'OPEN',
                triggered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                acknowledged_at DATETIME NULL,
                resolved_at DATETIME NULL,
                value FLOAT DEFAULT 0.0,
                message TEXT,
                FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE,
                FOREIGN KEY (rule_id) REFERENCES alert_rules(id) ON DELETE CASCADE
            ) ENGINE=InnoDB
            \"\"\")
            
            # Users Table
            cursor.execute(\"\"\"
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(100) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                role VARCHAR(50) DEFAULT 'ADMIN',
                email VARCHAR(150)
            ) ENGINE=InnoDB
            \"\"\")
            
            # SSL Certificates Table
            cursor.execute(\"\"\"
            CREATE TABLE IF NOT EXISTS ssl_certificates (
                id INT AUTO_INCREMENT PRIMARY KEY,
                host_id INT NOT NULL,
                domain VARCHAR(255) UNIQUE NOT NULL,
                expiry_date DATETIME NULL,
                status VARCHAR(20) DEFAULT 'VALID',
                last_checked DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
            ) ENGINE=InnoDB
            \"\"\")
            
            # AI Insights Table
            cursor.execute(\"\"\"
            CREATE TABLE IF NOT EXISTS ai_insights (
                id INT AUTO_INCREMENT PRIMARY KEY,
                host_id INT NULL,
                insight_type VARCHAR(50) NOT NULL,
                summary TEXT,
                analysis TEXT,
                generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
            ) ENGINE=InnoDB
            \"\"\")
            
            # Events Table
            cursor.execute(\"\"\"
            CREATE TABLE IF NOT EXISTS events (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                host_id INT NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                event_type VARCHAR(100),
                message TEXT,
                severity VARCHAR(20) DEFAULT 'INFO',
                FOREIGN KEY (host_id) REFERENCES hosts(id) ON DELETE CASCADE
            ) ENGINE=InnoDB
            \"\"\")
            
            # Network Discovery Ranges Table
            cursor.execute(\"\"\"
            CREATE TABLE IF NOT EXISTS network_ranges (
                id INT AUTO_INCREMENT PRIMARY KEY,
                subnet VARCHAR(100) UNIQUE NOT NULL,
                is_active TINYINT(1) DEFAULT 1
            ) ENGINE=InnoDB
            \"\"\")
            
            cursor.execute("SET FOREIGN_KEY_CHECKS = 1")
            
            # Seed Default Admin User
            cursor.execute("SELECT COUNT(*) as count FROM users WHERE username = %s", (Config.ADMIN_USER,))
            if cursor.fetchone()['count'] == 0:
                from werkzeug.security import generate_password_hash
                pwd_hash = generate_password_hash(Config.ADMIN_PASSWORD)
                cursor.execute(
                    "INSERT INTO users (username, password_hash, role, email) VALUES (%s, %s, 'ADMIN', 'admin@syswatch.local')",
                    (Config.ADMIN_USER, pwd_hash)
                )
            
            # Seed Default Alert Rules
            cursor.execute("SELECT COUNT(*) as count FROM alert_rules")
            if cursor.fetchone()['count'] == 0:
                default_rules = [
                    ("High CPU Warning", "cpu_percent", ">", 90.0, "The host {hostname} is reporting critical CPU usage at {value}%."),
                    ("Memory Exhaustion Danger", "memory_percent", ">", 85.0, "The host {hostname} is reporting a high memory usage of {value}%."),
                    ("Out of Disk Space", "disk_percent", ">", 95.0, "The host {hostname} is reporting critical disk capacity exhaustion at {value}%.")
                ]
                for name, metric, op, threshold, template in default_rules:
                    cursor.execute(
                        "INSERT INTO alert_rules (name, metric_name, operator, threshold, email_template) VALUES (%s, %s, %s, %s, %s)",
                        (name, metric, op, threshold, template)
                    )
                    
            logging.info("Database schemas and seed resources loaded successfully.")
    except Exception as e:
        logging.error(f"Database schema initialization failed: {e}")
"""

FILES["core/scheduler.py"] = """import logging
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

scheduler = BackgroundScheduler()

def start_scheduler(app):
    if not scheduler.running:
        from modules.monitoring_checks.status_updater import compute_status
        from modules.monitoring_checks.ssl_expiry import check_all_certificates
        from modules.ai.anomaly import run_anomaly_detection, run_predictions, send_daily_briefing
        from modules.alert_engine.auto_resolve import auto_resolve_stale_alerts

        def run_with_context(func):
            def wrapper():
                with app.app_context():
                    try:
                        func()
                    except Exception as e:
                        logging.error(f"Scheduler job {func.__name__} failed: {e}")
            return wrapper

        # 1. Host Health/Online Status Sync (Every 30s)
        scheduler.add_job(run_with_context(compute_status), 'interval', seconds=30, id='status_sync')
        # 2. SSL Expiry Warnings (Daily at 8am)
        scheduler.add_job(run_with_context(check_all_certificates), CronTrigger(hour=8, minute=0), id='ssl_sync')
        # 3. Dynamic Anomaly Detections (Every 5 minutes)
        scheduler.add_job(run_with_context(run_anomaly_detection), 'interval', minutes=5, id='anomaly_detection')
        # 4. DeepSeek Predictive Forecasting (Every 6 hours)
        scheduler.add_job(run_with_context(run_predictions), 'interval', hours=6, id='predictive_run')
        # 5. Stale Alert Auto-Resolutions (Every 10 minutes)
        scheduler.add_job(run_with_context(auto_resolve_stale_alerts), 'interval', minutes=10, id='auto_resolve')
        # 6. Daily Administrative Briefings (Daily at 8am)
        scheduler.add_job(run_with_context(send_daily_briefing), CronTrigger(hour=8, minute=0), id='daily_brief')

        scheduler.start()
        logging.info("APScheduler back-end jobs registered and started successfully.")

def shutdown_scheduler():
    if scheduler.running:
        scheduler.shutdown()
        logging.info("APScheduler monitoring jobs shut down safely.")
"""

FILES["core/app.py"] = """from flask import Flask
from flask_login import LoginManager
from core.config import Config
from core.database import init_db
from core.scheduler import start_scheduler
import logging

login_manager = LoginManager()
login_manager.login_view = 'auth_bp.login'

def create_app():
    app = Flask(__name__, template_folder='../modules/web_ui/templates', static_folder='../modules/web_ui/static')
    app.config.from_object(Config)

    # Logging config
    logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')

    # Initializing DB
    init_db()

    # Initializing Login Engine
    login_manager.init_app(app)

    # Blueprint routing configurations
    from modules.authentication.routes import auth_bp
    from modules.web_ui.routes import ui_bp
    from modules.api.routes import api_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(ui_bp)
    app.register_blueprint(api_bp, url_prefix='/api')

    # Prevent double scheduling inside Flask's developmental multi-threaded debugger reloaders
    import os
    if os.environ.get("WERKZEUG_RUN_MAIN") == "true" or not app.debug:
        start_scheduler(app)

    return app
"""

# -------------------------------------------------------------
# 2. MODULES - AUTHENTICATION
# -------------------------------------------------------------

FILES["modules/__init__.py"] = ""
FILES["modules/authentication/__init__.py"] = ""

FILES["modules/authentication/models.py"] = """from flask_login import UserMixin
from core.database import get_db
import pymysql

class User(UserMixin):
    def __init__(self, user_id, username, role, email):
        self.id = user_id
        self.username = username
        self.role = role
        self.email = email

    @staticmethod
    def get(user_id):
        conn = get_db()
        try:
            with conn.cursor(pymysql.cursors.DictCursor) as cursor:
                cursor.execute("SELECT id, username, role, email FROM users WHERE id = %s", (user_id,))
                user_data = cursor.fetchone()
                if user_data:
                    return User(user_data['id'], user_data['username'], user_data['role'], user_data['email'])
        except Exception as e:
            pass
        return None

from core.app import login_manager
@login_manager.user_loader
def load_user(user_id):
    return User.get(int(user_id))
"""

FILES["modules/authentication/routes.py"] = """from flask import Blueprint, request, render_template, redirect, url_for, flash, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from core.database import get_db
from modules.authentication.models import User
import pymysql

auth_bp = Blueprint('auth_bp', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('ui_bp.dashboard'))

    if request.method == 'POST':
        if request.is_json:
            data = request.get_json()
            username = data.get('username')
            password = data.get('password')
        else:
            username = request.form.get('username')
            password = request.form.get('password')

        conn = get_db()
        try:
            with conn.cursor(pymysql.cursors.DictCursor) as cursor:
                cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
                user_data = cursor.fetchone()
                if user_data and check_password_hash(user_data['password_hash'], password):
                    user = User(user_data['id'], user_data['username'], user_data['role'], user_data['email'])
                    login_user(user)
                    if request.is_json:
                        return jsonify({"status": "success", "message": "Sign-in successful."})
                    return redirect(url_for('ui_bp.dashboard'))
        except Exception as e:
            if request.is_json:
                return jsonify({"status": "error", "message": str(e)}), 500
            flash(f"Database connectivity failed: {e}", "danger")

        if request.is_json:
            return jsonify({"status": "error", "message": "Invalid password credentials."}), 401
        flash("Invalid username or security credentials", "danger")

    return render_template('login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth_bp.login'))

@auth_bp.route('/api/users', methods=['GET', 'POST'])
@login_required
def manage_users():
    if current_user.role != 'ADMIN':
        return jsonify({"status": "error", "message": "Administrative authorization required."}), 403

    conn = get_db()
    if request.method == 'GET':
        try:
            with conn.cursor(pymysql.cursors.DictCursor) as cursor:
                cursor.execute("SELECT id, username, role, email FROM users")
                users = cursor.fetchall()
                return jsonify(users)
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500

    if request.method == 'POST':
        data = request.get_json() or {}
        username = data.get('username')
        password = data.get('password')
        role = data.get('role', 'VIEWER')
        email = data.get('email', '')

        if not username or not password:
            return jsonify({"status": "error", "message": "Missing required fields username/password."}), 400

        pwd_hash = generate_password_hash(password)
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO users (username, password_hash, role, email) VALUES (%s, %s, %s, %s)",
                    (username, pwd_hash, role, email)
                )
            conn.commit()
            return jsonify({"status": "success", "message": f"User {username} spawned successfully."})
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500
"""

# -------------------------------------------------------------
# 3. MODULES - WEB_UI & TEMPLATES
# -------------------------------------------------------------

FILES["modules/web_ui/__init__.py"] = ""

FILES["modules/web_ui/routes.py"] = """from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required, current_user

ui_bp = Blueprint('ui_bp', __name__)

@ui_bp.route('/')
@login_required
def dashboard():
    return render_template('dashboard.html')
"""

FILES["modules/web_ui/templates/login.html"] = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SysWatch - Identity Gateway</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-slate-950 text-slate-100 flex items-center justify-center min-h-screen relative overflow-hidden">
    <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-900/20 via-slate-950 to-slate-950 -z-10"></div>
    <div class="w-full max-w-md p-8 bg-slate-900/60 backdrop-blur-md rounded-2xl shadow-2xl border border-slate-800/80">
        <div class="text-center mb-8">
            <h1 class="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-500 tracking-tight">SYSWATCH</h1>
            <p class="text-slate-400 mt-2 text-sm">v1.1.0 Enterprise Monitoring Dashboard</p>
        </div>
        
        {% with messages = get_flashed_messages(with_categories=true) %}
          {% if messages %}
            {% for category, msg in messages %}
              <div class="mb-5 p-3 bg-red-950/40 border border-red-500/40 text-red-200 text-sm rounded-lg">
                {{ msg }}
              </div>
            {% endfor %}
          {% endif %}
        {% endwith %}

        <form action="/login" method="POST" class="space-y-6">
            <div>
                <label for="username" class="block text-xs font-semibold text-slate-400 uppercase tracking-wider">Username</label>
                <input type="text" id="username" name="username" required placeholder="admin"
                    class="mt-2 block w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition">
            </div>
            <div>
                <label for="password" class="block text-xs font-semibold text-slate-400 uppercase tracking-wider">Password</label>
                <input type="password" id="password" name="password" required placeholder="••••••••"
                    class="mt-2 block w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition">
            </div>
            <div>
                <button type="submit"
                    class="w-full py-3 px-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 rounded-xl text-white font-semibold shadow-lg hover:shadow-blue-500/10 transition duration-200 cursor-pointer">
                    Authenticate
                </button>
            </div>
        </form>
    </div>
</body>
</html>
"""

FILES["modules/web_ui/templates/dashboard.html"] = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SysWatch v1.1.0 - Administration</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .code-font { font-family: 'JetBrains Mono', monospace; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
    </style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen flex">

    <!-- Sidebar Menu Nav -->
    <div class="w-64 bg-slate-900 border-r border-slate-800 flex flex-col shrink-0">
        <div class="p-6 border-b border-slate-800">
            <div class="flex items-center space-x-3">
                <div class="p-2 bg-blue-600/10 rounded-lg text-blue-500 border border-blue-500/20">
                    <i class="fa-solid fa-server text-lg"></i>
                </div>
                <div>
                    <h2 class="text-xl font-bold tracking-tight text-white">SYSWATCH</h2>
                    <p class="text-xs text-slate-500">v1.1.0 Admin Console</p>
                </div>
            </div>
        </div>

        <nav class="flex-1 p-4 space-y-1" id="sidebar-nav">
            <button data-tab="dashboard" class="sidebar-btn w-full flex items-center space-x-3 px-4 py-3 text-slate-400 hover:bg-slate-800/50 hover:text-white rounded-xl transition cursor-pointer text-left">
                <i class="fa-solid fa-chart-line text-sm shrink-0 w-5"></i>
                <span class="text-sm font-medium">Dashboard Overview</span>
            </button>
            <button data-tab="hosts" class="sidebar-btn w-full flex items-center space-x-3 px-4 py-3 text-slate-400 hover:bg-slate-800/50 hover:text-white rounded-xl transition cursor-pointer text-left">
                <i class="fa-solid fa-network-wired text-sm shrink-0 w-5"></i>
                <span class="text-sm font-medium">Hosts & Status</span>
            </button>
            <button data-tab="alerts" class="sidebar-btn w-full flex items-center space-x-3 px-4 py-3 text-slate-400 hover:bg-slate-800/50 hover:text-white rounded-xl transition cursor-pointer text-left">
                <i class="fa-solid fa-bell-exclamation text-sm shrink-0 w-5"></i>
                <span class="text-sm font-medium">Active Alerts</span>
            </button>
            <button data-tab="rules" class="sidebar-btn w-full flex items-center space-x-3 px-4 py-3 text-slate-400 hover:bg-slate-800/50 hover:text-white rounded-xl transition cursor-pointer text-left">
                <i class="fa-solid fa-gears text-sm shrink-0 w-5"></i>
                <span class="text-sm font-medium">Rule Config</span>
            </button>
            <button data-tab="ai-insights" class="sidebar-btn w-full flex items-center space-x-3 px-4 py-3 text-slate-400 hover:bg-slate-800/50 hover:text-white rounded-xl transition cursor-pointer text-left">
                <i class="fa-solid fa-brain text-sm shrink-0 w-5"></i>
                <span class="text-sm font-medium">AI Insights</span>
            </button>
            <button data-tab="discovery" class="sidebar-btn w-full flex items-center space-x-3 px-4 py-3 text-slate-400 hover:bg-slate-800/50 hover:text-white rounded-xl transition cursor-pointer text-left">
                <i class="fa-solid fa-radar text-sm shrink-0 w-5"></i>
                <span class="text-sm font-medium">Auto Discovery</span>
            </button>
            <button data-tab="admin" class="sidebar-btn w-full flex items-center space-x-3 px-4 py-3 text-slate-400 hover:bg-slate-800/50 hover:text-white rounded-xl transition cursor-pointer text-left">
                <i class="fa-solid fa-user-shield text-sm shrink-0 w-5"></i>
                <span class="text-sm font-medium">Admin & Audits</span>
            </button>
        </nav>

        <div class="p-4 border-t border-slate-800 bg-slate-900/50">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-xs font-semibold text-slate-400">Authenticated As</p>
                    <p class="text-xs text-slate-500 italic truncate" id="current-username">Admin User</p>
                </div>
                <a href="/logout" class="p-2 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition" title="Logout">
                    <i class="fa-solid fa-right-from-bracket"></i>
                </a>
            </div>
        </div>
    </div>

    <!-- Main Content Panel -->
    <div class="flex-1 flex flex-col min-w-0 overflow-y-auto">
        <!-- Top bar with aggregate statistics -->
        <header class="bg-slate-900 border-b border-slate-800 py-4 px-8 flex justify-between items-center shrink-0">
            <div>
                <h1 class="text-xl font-bold text-white tracking-tight" id="active-tab-title">Dashboard Overview</h1>
            </div>
            <div class="flex items-center space-x-6">
                <div class="flex space-x-4 text-xs">
                    <div class="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800"><span class="text-slate-500 mr-1.5">Hosts:</span><b id="summary-total-hosts">0</b></div>
                    <div class="bg-green-500/10 px-3 py-1.5 rounded-lg border border-green-500/20 text-green-400"><span class="text-green-500/60 mr-1.5">Up:</span><b id="summary-up-hosts">0</b></div>
                    <div class="bg-yellow-500/10 px-3 py-1.5 rounded-lg border border-yellow-500/20 text-yellow-400"><span class="text-yellow-500/60 mr-1.5">Warning:</span><b id="summary-warning-hosts">0</b></div>
                    <div class="bg-red-500/10 px-3 py-1.5 rounded-lg border border-red-500/20 text-red-400"><span class="text-red-500/60 mr-1.5">Down:</span><b id="summary-down-hosts">0</b></div>
                </div>
                <button onclick="refreshData()" class="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 rounded-lg text-xs font-semibold tracking-wide transition cursor-pointer">
                    <i class="fa-solid fa-arrows-rotate mr-1.5"></i> Refresh
                </button>
            </div>
        </header>

        <main class="flex-1 p-8">
            <!-- ----------------------------------------- -->
            <!-- TAB 1: DASHBOARD OVERVIEW -->
            <!-- ----------------------------------------- -->
            <div id="tab-dashboard" class="tab-content active space-y-8">
                <!-- Summary Statistics Grid -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div class="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
                        <p class="text-xs font-bold uppercase tracking-wider text-slate-500">System Capacity</p>
                        <h3 class="text-3xl font-bold mt-2" id="dash-total-hosts">0</h3>
                        <p class="text-xs text-slate-400 mt-1">Total active monitored hosts</p>
                    </div>
                    <div class="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
                        <p class="text-xs font-bold uppercase tracking-wider text-slate-500">Live Services</p>
                        <h3 class="text-3xl font-bold mt-2 text-green-400" id="dash-up-hosts">0</h3>
                        <p class="text-xs text-slate-400 mt-1">Nodes reporting healthy seen status</p>
                    </div>
                    <div class="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
                        <p class="text-xs font-bold uppercase tracking-wider text-slate-500">Degraded Nodes</p>
                        <h3 class="text-3xl font-bold mt-2 text-yellow-400" id="dash-warning-hosts">0</h3>
                        <p class="text-xs text-slate-400 mt-1">Stale reporting intervals detected</p>
                    </div>
                    <div class="bg-slate-900 border border-slate-800 p-6 rounded-2xl">
                        <p class="text-xs font-bold uppercase tracking-wider text-slate-500">Active Alert States</p>
                        <h3 class="text-3xl font-bold mt-2 text-red-500" id="dash-active-alerts">0</h3>
                        <p class="text-xs text-slate-400 mt-1">Breached metric threshold boundaries</p>
                    </div>
                </div>

                <!-- Host Status Summary Table -->
                <div class="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                    <div class="p-6 border-b border-slate-800 flex justify-between items-center">
                        <h3 class="font-bold text-white text-lg">Monitored Systems Status</h3>
                        <select id="group-filter" class="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-lg text-xs" onchange="loadHosts()">
                            <option value="">All Groups</option>
                        </select>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-sm text-slate-300">
                            <thead class="bg-slate-950 text-slate-400 uppercase text-xs font-bold border-b border-slate-800">
                                <tr>
                                    <th class="px-6 py-4">Host Name</th>
                                    <th class="px-6 py-4">Status</th>
                                    <th class="px-6 py-4">Operating System</th>
                                    <th class="px-6 py-4">CPU Utilization</th>
                                    <th class="px-6 py-4">RAM Utilization</th>
                                    <th class="px-6 py-4">Disk Utilization</th>
                                    <th class="px-6 py-4">Last Seen</th>
                                </tr>
                            </thead>
                            <tbody id="dash-hosts-tbody" class="divide-y divide-slate-800">
                                <tr>
                                    <td colspan="7" class="px-6 py-8 text-center text-slate-500">Querying active monitoring metrics...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- ----------------------------------------- -->
            <!-- TAB 2: HOSTS AND STATUS -->
            <!-- ----------------------------------------- -->
            <div id="tab-hosts" class="tab-content space-y-8">
                <!-- Manual Add Host -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div class="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
                        <h3 class="text-lg font-bold text-white">Manual Node Registration</h3>
                        <form id="add-host-form" onsubmit="addHost(event)" class="space-y-4">
                            <div>
                                <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider">Hostname</label>
                                <input type="text" id="host-name" required placeholder="production-srv-01" class="mt-1.5 block w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-slate-100">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider">IP Address</label>
                                <input type="text" id="host-ip" required placeholder="192.168.1.15" class="mt-1.5 block w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-slate-100">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider">OS Platform</label>
                                <input type="text" id="host-os" required placeholder="Ubuntu 22.04" class="mt-1.5 block w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-slate-100">
                            </div>
                            <button type="submit" class="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-sm transition cursor-pointer">Register Host</button>
                        </form>
                    </div>

                    <!-- Trend Chart Graph View -->
                    <div class="bg-slate-900 border border-slate-800 p-6 rounded-2xl md:col-span-2 space-y-4">
                        <div class="flex justify-between items-center">
                            <h3 class="text-lg font-bold text-white">Resource Trends Analyst</h3>
                            <div class="flex space-x-2">
                                <select id="trend-host-select" class="bg-slate-950 border border-slate-800 px-2.5 py-1 rounded text-xs" onchange="loadTrendData()"></select>
                                <select id="trend-metric-select" class="bg-slate-950 border border-slate-800 px-2.5 py-1 rounded text-xs" onchange="loadTrendData()">
                                    <option value="cpu_percent">CPU %</option>
                                    <option value="memory_percent">RAM %</option>
                                    <option value="disk_percent">Disk %</option>
                                </select>
                                <select id="trend-range-select" class="bg-slate-950 border border-slate-800 px-2.5 py-1 rounded text-xs" onchange="loadTrendData()">
                                    <option value="1h">Last 1h</option>
                                    <option value="6h">Last 6h</option>
                                    <option value="24h">Last 24h</option>
                                </select>
                            </div>
                        </div>
                        <div class="h-64 relative">
                            <canvas id="trendChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ----------------------------------------- -->
            <!-- TAB 3: ACTIVE ALERTS -->
            <!-- ----------------------------------------- -->
            <div id="tab-alerts" class="tab-content space-y-8">
                <div class="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                    <div class="p-6 border-b border-slate-800 flex justify-between items-center">
                        <h3 class="font-bold text-white text-lg">Active System Alerts</h3>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left text-sm text-slate-300">
                            <thead class="bg-slate-950 text-slate-400 uppercase text-xs font-bold border-b border-slate-800">
                                <tr>
                                    <th class="px-6 py-4">Triggered Time</th>
                                    <th class="px-6 py-4">Host Name</th>
                                    <th class="px-6 py-4">Severity Rule</th>
                                    <th class="px-6 py-4">Trigger Metric Value</th>
                                    <th class="px-6 py-4">Alert Narrative</th>
                                    <th class="px-6 py-4">Status</th>
                                    <th class="px-6 py-4 text-right">Operations</th>
                                </tr>
                            </thead>
                            <tbody id="alerts-tbody" class="divide-y divide-slate-800">
                                <tr>
                                    <td colspan="7" class="px-6 py-8 text-center text-slate-500">Scanning incident boards...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- ----------------------------------------- -->
            <!-- TAB 4: RULE CONFIG -->
            <!-- ----------------------------------------- -->
            <div id="tab-rules" class="tab-content space-y-8">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <!-- Create Rule Panel -->
                    <div class="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
                        <h3 class="text-lg font-bold text-white">Create Threshold Rule</h3>
                        <form id="add-rule-form" onsubmit="addRule(event)" class="space-y-4">
                            <div>
                                <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider">Rule Name</label>
                                <input type="text" id="rule-name" required placeholder="CPU Critical Outage" class="mt-1.5 block w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-slate-100">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider">Metric Source</label>
                                <select id="rule-metric" class="mt-1.5 block w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-slate-300">
                                    <option value="cpu_percent">CPU Percent (%)</option>
                                    <option value="memory_percent">Memory Percent (%)</option>
                                    <option value="disk_percent">Disk Percent (%)</option>
                                </select>
                            </div>
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider">Operator</label>
                                    <select id="rule-operator" class="mt-1.5 block w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-slate-300">
                                        <option value=">">&gt;</option>
                                        <option value="<">&lt;</option>
                                        <option value="==">==</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider">Threshold Value</label>
                                    <input type="number" step="0.1" id="rule-threshold" required placeholder="90" class="mt-1.5 block w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-slate-100">
                                </div>
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider">Notification Narrative</label>
                                <textarea id="rule-template" rows="3" required placeholder="The host {hostname} exceeded limit thresholds reporting {value}%" class="mt-1.5 block w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-slate-100"></textarea>
                            </div>
                            <button type="submit" class="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-sm transition cursor-pointer">Establish Rule</button>
                        </form>
                    </div>

                    <!-- Existing Rules Table -->
                    <div class="bg-slate-900 border border-slate-800 p-6 rounded-2xl md:col-span-2 overflow-hidden flex flex-col">
                        <h3 class="text-lg font-bold text-white mb-4">Active Monitoring Rules</h3>
                        <div class="overflow-x-auto flex-1">
                            <table class="w-full text-left text-sm text-slate-300">
                                <thead class="bg-slate-950 text-slate-400 uppercase text-xs font-bold border-b border-slate-800">
                                    <tr>
                                        <th class="px-6 py-4">Rule Name</th>
                                        <th class="px-6 py-4">Metric Target</th>
                                        <th class="px-6 py-4">Logical Trigger</th>
                                        <th class="px-6 py-4">Threshold</th>
                                        <th class="px-6 py-4">Enabled</th>
                                        <th class="px-6 py-4 text-right">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="rules-tbody" class="divide-y divide-slate-800">
                                    <tr>
                                        <td colspan="6" class="px-6 py-8 text-center text-slate-500">Querying threshold catalog...</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ----------------------------------------- -->
            <!-- TAB 5: AI INSIGHTS -->
            <!-- ----------------------------------------- -->
            <div id="tab-ai-insights" class="tab-content space-y-8">
                <!-- DeepSeek AI Insights -->
                <div class="bg-slate-900 border border-slate-800 p-8 rounded-2xl space-y-6">
                    <div class="flex items-center space-x-3.5 pb-4 border-b border-slate-800">
                        <div class="p-3 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 rounded-xl text-cyan-400 border border-cyan-500/20">
                            <i class="fa-solid fa-brain text-xl"></i>
                        </div>
                        <div>
                            <h3 class="text-xl font-bold text-white">DeepSeek Cognitive Operations Analysis</h3>
                            <p class="text-xs text-slate-500">Real-time troubleshooting diagnostics, predictive analytics, and automated shift briefings.</p>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div class="lg:col-span-2 space-y-6">
                            <h4 class="text-sm font-bold uppercase tracking-wider text-slate-400">Chronological Insight Stream</h4>
                            <div id="ai-insights-stream" class="space-y-4 max-h-[500px] overflow-y-auto pr-2">
                                <div class="p-5 bg-slate-950 border border-slate-800 rounded-xl">
                                    <p class="text-slate-500 text-sm">No administrative briefings generated today.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Local Model Standalone Fallbacks -->
                        <div class="bg-slate-950/80 border border-slate-800 p-6 rounded-2xl space-y-4">
                            <h4 class="text-sm font-bold uppercase tracking-wider text-slate-300">Model Configuration</h4>
                            <div class="p-4 bg-slate-900/50 rounded-xl border border-slate-800 space-y-3">
                                <div class="flex justify-between text-xs">
                                    <span class="text-slate-500">Active Pipeline:</span>
                                    <span class="text-blue-400 font-bold uppercase">DeepSeek API</span>
                                </div>
                                <div class="flex justify-between text-xs">
                                    <span class="text-slate-500">Diagnostics Model:</span>
                                    <span class="text-slate-300 code-font">deepseek-chat</span>
                                </div>
                                <div class="flex justify-between text-xs">
                                    <span class="text-slate-500">Local Fallback:</span>
                                    <span class="text-green-500 font-bold uppercase">Active (Sigma-3)</span>
                                </div>
                            </div>
                            <p class="text-xs text-slate-500 leading-relaxed">If your environment lacks active external network routes to DeepSeek servers, the core daemon falls back to statistical regression algorithms to detect anomalies locally.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ----------------------------------------- -->
            <!-- TAB 6: AUTO DISCOVERY -->
            <!-- ----------------------------------------- -->
            <div id="tab-discovery" class="tab-content space-y-8">
                <div class="bg-slate-900 border border-slate-800 p-8 rounded-2xl space-y-6">
                    <div class="flex items-center space-x-3.5 pb-4 border-b border-slate-800">
                        <div class="p-3 bg-blue-600/10 rounded-xl text-blue-400 border border-blue-500/20">
                            <i class="fa-solid fa-radar text-xl"></i>
                        </div>
                        <div>
                            <h3 class="text-xl font-bold text-white">Subnet Host Auto-Discovery</h3>
                            <p class="text-xs text-slate-500">Trigger multi-threaded ping sweeps to identify live network assets and automatically append them to monitoring checklists.</p>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                        <div class="space-y-4 bg-slate-950 border border-slate-800 p-6 rounded-xl">
                            <h4 class="text-sm font-bold uppercase text-slate-400 tracking-wider">Trigger Discovery Job</h4>
                            <div class="space-y-3">
                                <div>
                                    <label class="block text-xs font-semibold text-slate-500">Target CIDR Subnet</label>
                                    <input type="text" id="discovery-subnet-input" placeholder="192.168.1.0/24" value="192.168.1.0/24" class="mt-1.5 block w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-sm text-slate-100">
                                </div>
                                <button onclick="triggerDiscovery()" class="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-sm transition cursor-pointer">
                                    <i class="fa-solid fa-play mr-1.5"></i> Launch Sweep
                                </button>
                            </div>
                        </div>

                        <!-- Progress Display -->
                        <div class="md:col-span-2 bg-slate-950 border border-slate-800 p-6 rounded-xl flex flex-col justify-between">
                            <div>
                                <h4 class="text-sm font-bold uppercase text-slate-400 tracking-wider mb-2">Sweep Engine Telemetry</h4>
                                <p id="discovery-status-text" class="text-xs text-slate-500">Discovery Engine idle.</p>
                            </div>
                            <div class="space-y-2 mt-4">
                                <div class="w-full bg-slate-900 rounded-full h-2.5">
                                    <div id="discovery-progress-bar" class="bg-blue-500 h-2.5 rounded-full" style="width: 0%"></div>
                                </div>
                                <div class="flex justify-between text-xs text-slate-500">
                                    <span>Engine Progress: <b id="discovery-progress-percent">0%</b></span>
                                    <span>Found Nodes: <b id="discovery-found-count">0</b></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ----------------------------------------- -->
            <!-- TAB 7: ADMIN & AUDITS -->
            <!-- ----------------------------------------- -->
            <div id="tab-admin" class="tab-content space-y-8">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <!-- User Control List -->
                    <div class="bg-slate-900 border border-slate-800 p-6 rounded-2xl flex flex-col">
                        <h3 class="text-lg font-bold text-white mb-4">Identity Security Access Control</h3>
                        <div class="overflow-x-auto flex-1">
                            <table class="w-full text-left text-sm text-slate-300">
                                <thead class="bg-slate-950 text-slate-400 uppercase text-xs font-bold border-b border-slate-800">
                                    <tr>
                                        <th class="px-6 py-4">User</th>
                                        <th class="px-6 py-4">Role</th>
                                        <th class="px-6 py-4">Email</th>
                                    </tr>
                                </thead>
                                <tbody id="users-tbody" class="divide-y divide-slate-800">
                                    <tr>
                                        <td colspan="3" class="px-6 py-8 text-center text-slate-500">Loading user registries...</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Spawning users -->
                    <div class="bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
                        <h3 class="text-lg font-bold text-white">Register Administrative Account</h3>
                        <form id="add-user-form" onsubmit="addUser(event)" class="space-y-4">
                            <div>
                                <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider">Username</label>
                                <input type="text" id="user-name" required placeholder="sys_audit_operator" class="mt-1.5 block w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-slate-100">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider">Security Password</label>
                                <input type="password" id="user-password" required placeholder="••••••••" class="mt-1.5 block w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-slate-100">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider">System Role</label>
                                <select id="user-role" class="mt-1.5 block w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-slate-300">
                                    <option value="ADMIN">ADMIN (Full Access)</option>
                                    <option value="VIEWER">VIEWER (Read Only)</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-xs font-semibold text-slate-400 uppercase tracking-wider">Email Address</label>
                                <input type="email" id="user-email" required placeholder="operator@syswatch.local" class="mt-1.5 block w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-slate-100">
                            </div>
                            <button type="submit" class="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-sm transition cursor-pointer">Spawn User</button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Core Interactive Client Scripting -->
    <script>
        document.addEventListener("DOMContentLoaded", () => {
            // Tab Toggle system routing
            const btns = document.querySelectorAll("#sidebar-nav button");
            btns.forEach(btn => {
                btn.addEventListener("click", () => {
                    const tabId = btn.getAttribute("data-tab");
                    switchTab(tabId);
                });
            });

            // Initial load commands
            refreshData();
            initChart();

            // Auto status updater intervals (Every 15 seconds)
            setInterval(refreshData, 15000);
        });

        function switchTab(tabId) {
            // Update UI Sidebar buttons
            document.querySelectorAll("#sidebar-nav button").forEach(b => {
                b.classList.remove("bg-slate-800", "text-white");
                b.classList.add("text-slate-400");
            });
            const activeBtn = document.querySelector(`#sidebar-nav button[data-tab="${tabId}"]`);
            if (activeBtn) {
                activeBtn.classList.add("bg-slate-800", "text-white");
            }

            // Update visible sections
            document.querySelectorAll(".tab-content").forEach(tab => {
                tab.classList.remove("active");
            });
            const activeTabSection = document.getElementById(`tab-${tabId}`);
            if (activeTabSection) {
                activeTabSection.classList.add("active");
            }

            // Set Header name
            const headers = {
                'dashboard': 'Dashboard Overview',
                'hosts': 'Host Inventory & Analytics',
                'alerts': 'Incident Board & Logs',
                'rules': 'Metric Boundaries Rules Config',
                'ai-insights': 'AI Operations Engine Diagnostics',
                'discovery': 'Subnetwork Discovery Scanner',
                'admin': 'Admin & Access Audits'
            };
            document.getElementById("active-tab-title").innerText = headers[tabId] || 'SysWatch Console';
        }

        async function refreshData() {
            try {
                const [summaryRes, hostsRes, alertsRes, rulesRes, aiRes, usersRes] = await Promise.all([
                    axios.get('/api/summary'),
                    axios.get('/api/latest'),
                    axios.get('/api/alerts'),
                    axios.get('/api/rules'),
                    axios.get('/api/ai_insights'),
                    axios.get('/api/users').catch(() => ({ data: [] }))
                ]);

                // 1. Load Headers / Summaries statistics
                const s = summaryRes.data;
                document.getElementById("summary-total-hosts").innerText = s.total_hosts || 0;
                document.getElementById("summary-up-hosts").innerText = s.up_hosts || 0;
                document.getElementById("summary-warning-hosts").innerText = s.warning_hosts || 0;
                document.getElementById("summary-down-hosts").innerText = s.down_hosts || 0;

                document.getElementById("dash-total-hosts").innerText = s.total_hosts || 0;
                document.getElementById("dash-up-hosts").innerText = s.up_hosts || 0;
                document.getElementById("dash-warning-hosts").innerText = s.warning_hosts || 0;
                document.getElementById("dash-active-alerts").innerText = s.active_alerts || 0;

                // 2. Render Hosts Table Grid
                const hTbody = document.getElementById("dash-hosts-tbody");
                hTbody.innerHTML = '';
                const hosts = hostsRes.data;

                // Sync trends host picker options
                const trendHostSelect = document.getElementById("trend-host-select");
                const currentSel = trendHostSelect.value;
                trendHostSelect.innerHTML = '';

                if (hosts.length === 0) {
                    hTbody.innerHTML = `<tr><td colspan="7" class="px-6 py-6 text-center text-slate-500">No active reporting systems linked. Set up host agents.</td></tr>`;
                } else {
                    hosts.forEach(h => {
                        // Populate selector options
                        const opt = document.createElement("option");
                        opt.value = h.hostname;
                        opt.innerText = h.hostname;
                        trendHostSelect.appendChild(opt);

                        // Generate table row details
                        const statusColor = h.status === 'UP' ? 'bg-green-500' : (h.status === 'WARNING' ? 'bg-yellow-500' : 'bg-red-500');
                        const row = `
                            <tr>
                                <td class="px-6 py-4 font-bold text-white text-xs">${h.hostname}<br><span class="text-[10px] text-slate-500 font-normal code-font">${h.ip_address || 'Unassigned'}</span></td>
                                <td class="px-6 py-4"><span class="flex items-center space-x-1.5"><span class="w-2 h-2 rounded-full ${statusColor}"></span> <span class="text-xs uppercase font-semibold">${h.status}</span></span></td>
                                <td class="px-6 py-4 text-xs text-slate-400">${h.os_platform || 'Generic OS'}<br><span class="text-[10px] text-slate-500">v${h.agent_version || '1.1.0'}</span></td>
                                <td class="px-6 py-4 text-xs font-semibold text-slate-200">${(h.cpu_percent || 0.0).toFixed(1)}%</td>
                                <td class="px-6 py-4 text-xs font-semibold text-slate-200">${(h.memory_percent || 0.0).toFixed(1)}%</td>
                                <td class="px-6 py-4 text-xs font-semibold text-slate-200">${(h.disk_percent || 0.0).toFixed(1)}%</td>
                                <td class="px-6 py-4 text-[10px] text-slate-500 font-mono">${h.last_seen || 'Never'}</td>
                            </tr>
                        `;
                        hTbody.insertAdjacentHTML('beforeend', row);
                    });
                    if (currentSel) trendHostSelect.value = currentSel;
                }

                // 3. Render Incident Boards
                const alertsTbody = document.getElementById("alerts-tbody");
                alertsTbody.innerHTML = '';
                const alerts = alertsRes.data;

                if (alerts.length === 0) {
                    alertsTbody.innerHTML = `<tr><td colspan="7" class="px-6 py-6 text-center text-slate-500">Pristine telemetry status! No alerts raised.</td></tr>`;
                } else {
                    alerts.forEach(a => {
                        const isResolved = a.status === 'RESOLVED';
                        const isAcked = a.status === 'ACKNOWLEDGED';
                        const statusBadge = isResolved 
                            ? '<span class="bg-green-500/10 text-green-400 border border-green-500/20 px-2 py-0.5 rounded text-[10px] font-bold">RESOLVED</span>' 
                            : (isAcked 
                                ? '<span class="bg-yellow-500/10 text-yellow-400 border border-yellow-500/20 px-2 py-0.5 rounded text-[10px] font-bold">ACKNOWLEDGED</span>' 
                                : '<span class="bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded text-[10px] font-bold">OPEN</span>');
                        
                        const actions = isResolved 
                            ? '<span class="text-xs text-slate-500">No actions required</span>' 
                            : `<button onclick="ackAlert(${a.id})" class="px-2.5 py-1 bg-yellow-600/10 hover:bg-yellow-600/20 text-yellow-500 rounded border border-yellow-500/20 text-xs font-semibold cursor-pointer mr-1.5">Ack</button>`;

                        const row = `
                            <tr>
                                <td class="px-6 py-4 text-[10px] text-slate-500 font-mono">${a.triggered_at}</td>
                                <td class="px-6 py-4 font-bold text-white text-xs">${a.hostname}</td>
                                <td class="px-6 py-4 text-xs font-semibold text-red-400">${a.rule_name}</td>
                                <td class="px-6 py-4 text-xs text-slate-400">${a.value || 0}%</td>
                                <td class="px-6 py-4 text-xs text-slate-300">${a.message}</td>
                                <td class="px-6 py-4">${statusBadge}</td>
                                <td class="px-6 py-4 text-right">${actions}</td>
                            </tr>
                        `;
                        alertsTbody.insertAdjacentHTML('beforeend', row);
                    });
                }

                // 4. Render Catalog Config Rules
                const rulesTbody = document.getElementById("rules-tbody");
                rulesTbody.innerHTML = '';
                const rules = rulesRes.data;
                rules.forEach(r => {
                    const checkedState = r.is_enabled ? 'Checked' : '';
                    const row = `
                        <tr>
                            <td class="px-6 py-4 font-semibold text-white text-xs">${r.name}</td>
                            <td class="px-6 py-4 text-xs text-slate-400 code-font">${r.metric_name}</td>
                            <td class="px-6 py-4 text-xs text-slate-400 font-bold">${r.operator}</td>
                            <td class="px-6 py-4 text-xs text-slate-300 font-bold">${r.threshold}</td>
                            <td class="px-6 py-4"><input type="checkbox" ${checkedState} onchange="toggleRule(${r.id})" class="rounded border-slate-800 bg-slate-950 focus:ring-0 text-blue-600"></td>
                            <td class="px-6 py-4 text-right"><button onclick="deleteRule(${r.id})" class="p-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-500 border border-red-500/20 rounded cursor-pointer" title="Delete Rule"><i class="fa-solid fa-trash-can text-xs"></i></button></td>
                        </tr>
                    `;
                    rulesTbody.insertAdjacentHTML('beforeend', row);
                });

                // 5. Render AI Insight Streams
                const aiStream = document.getElementById("ai-insights-stream");
                aiStream.innerHTML = '';
                const insights = aiRes.data;

                if (insights.length === 0) {
                    aiStream.innerHTML = `
                        <div class="p-5 bg-slate-950 border border-slate-800 rounded-xl flex items-center space-x-3.5">
                            <i class="fa-solid fa-cloud-moon text-slate-600 text-xl shrink-0"></i>
                            <div>
                                <p class="text-sm font-semibold text-slate-400">DeepSeek API diagnostics idle.</p>
                                <p class="text-[11px] text-slate-500 mt-0.5">Register an active API Key and trigger metrics breach anomalies to generate intelligence briefs.</p>
                            </div>
                        </div>`;
                } else {
                    insights.forEach(ins => {
                        const icon = ins.insight_type === 'ANOMALY' ? 'fa-triangle-exclamation text-yellow-500 bg-yellow-500/10 border-yellow-500/20' : (ins.insight_type === 'FORECAST' ? 'fa-chart-area text-purple-400 bg-purple-500/10 border-purple-500/20' : 'fa-list-check text-blue-400 bg-blue-500/10 border-blue-500/20');
                        const row = `
                            <div class="p-5 bg-slate-950 border border-slate-800 rounded-xl space-y-3.5">
                                <div class="flex items-start justify-between">
                                    <div class="flex items-center space-x-3">
                                        <div class="p-2.5 rounded-lg border text-sm ${icon}">
                                            <i class="fa-solid"></i>
                                        </div>
                                        <div>
                                            <h4 class="text-xs font-bold text-white uppercase tracking-wide">${ins.summary}</h4>
                                            <p class="text-[10px] text-slate-500 mt-0.5">Scope: <span class="text-blue-400">${ins.hostname || 'Global'}</span> • Generated: ${ins.generated_at}</p>
                                        </div>
                                    </div>
                                    <span class="text-[10px] bg-slate-900 border border-slate-800 px-2 py-0.5 rounded text-slate-400 font-semibold tracking-wider">${ins.insight_type}</span>
                                </div>
                                <div class="text-xs text-slate-300 leading-relaxed bg-slate-900/40 p-3.5 rounded-lg border border-slate-800/50">${ins.analysis}</div>
                            </div>
                        `;
                        aiStream.insertAdjacentHTML('beforeend', row);
                    });
                }

                // 6. User accounts
                const usersTbody = document.getElementById("users-tbody");
                if (usersRes.data && usersRes.data.length > 0) {
                    usersTbody.innerHTML = '';
                    usersRes.data.forEach(u => {
                        const row = `
                            <tr>
                                <td class="px-6 py-4 font-semibold text-white text-xs">${u.username}</td>
                                <td class="px-6 py-4 text-xs"><span class="bg-slate-950 border border-slate-800 px-2 py-0.5 rounded font-mono text-[10px] text-blue-400 font-bold">${u.role}</span></td>
                                <td class="px-6 py-4 text-xs text-slate-400">${u.email || 'Unassigned'}</td>
                            </tr>
                        `;
                        usersTbody.insertAdjacentHTML('beforeend', row);
                    });
                }

            } catch (err) {
                console.error("Aggregation polling fails:", err);
            }
        }

        // -------------------------------------------------------------
        // AXIOS CONTROL OPERATIONS
        // -------------------------------------------------------------
        async function ackAlert(id) {
            try {
                await axios.post(`/api/alerts/${id}/acknowledge`);
                refreshData();
            } catch (e) { alert("Failed to acknowledge."); }
        }

        async function addHost(e) {
            e.preventDefault();
            const payload = {
                hostname: document.getElementById("host-name").value,
                ip_address: document.getElementById("host-ip").value,
                os_platform: document.getElementById("host-os").value
            };
            try {
                await axios.post('/api/hosts', payload);
                document.getElementById("add-host-form").reset();
                refreshData();
                switchTab('dashboard');
            } catch (err) { alert("Host allocation error."); }
        }

        async function addRule(e) {
            e.preventDefault();
            const payload = {
                name: document.getElementById("rule-name").value,
                metric_name: document.getElementById("rule-metric").value,
                operator: document.getElementById("rule-operator").value,
                threshold: parseFloat(document.getElementById("rule-threshold").value),
                email_template: document.getElementById("rule-template").value
            };
            try {
                await axios.post('/api/rules', payload);
                document.getElementById("add-rule-form").reset();
                refreshData();
            } catch (e) { alert("Failed to build rule."); }
        }

        async function toggleRule(id) {
            try {
                await axios.post(`/api/rules/${id}/toggle`);
                refreshData();
            } catch (e) { alert("Toggle update failed."); }
        }

        async function deleteRule(id) {
            if (!confirm("Are you sure you want to delete this rule?")) return;
            try {
                await axios.delete(`/api/rules/${id}`);
                refreshData();
            } catch (e) { alert("Delete rule failed."); }
        }

        async function addUser(e) {
            e.preventDefault();
            const payload = {
                username: document.getElementById("user-name").value,
                password: document.getElementById("user-password").value,
                role: document.getElementById("user-role").value,
                email: document.getElementById("user-email").value
            };
            try {
                await axios.post('/api/users', payload);
                document.getElementById("add-user-form").reset();
                refreshData();
            } catch (e) { alert("Access registration error."); }
        }

        // -------------------------------------------------------------
        // AUTO DISCOVERY LOGICS
        // -------------------------------------------------------------
        let discoverInterval = null;
        async function triggerDiscovery() {
            try {
                await axios.post('/api/discover/start');
                document.getElementById("discovery-status-text").innerText = "Multithreaded network sweep active...";
                pollDiscovery();
                if (discoverInterval) clearInterval(discoverInterval);
                discoverInterval = setInterval(pollDiscovery, 2000);
            } catch (err) { alert("Discovery block: Already running or configuration issues."); }
        }

        async function pollDiscovery() {
            try {
                const res = await axios.get('/api/discover/status');
                const d = res.data;
                
                document.getElementById("discovery-progress-bar").style.width = `${d.progress}%`;
                document.getElementById("discovery-progress-percent").innerText = `${d.progress}%`;
                document.getElementById("discovery-found-count").innerText = d.found_hosts.length;

                if (!d.is_running) {
                    clearInterval(discoverInterval);
                    document.getElementById("discovery-status-text").innerText = `Sweep completed! Located ${d.found_hosts.length} live IP configurations.`;
                    refreshData();
                }
            } catch (e) {}
        }

        // -------------------------------------------------------------
        // CHARTING LOGIC
        // -------------------------------------------------------------
        let myChart = null;
        function initChart() {
            const ctx = document.getElementById('trendChart').getContext('2d');
            myChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Resource Metric Data (%)',
                        borderColor: '#2563eb',
                        backgroundColor: 'rgba(37, 99, 235, 0.1)',
                        data: [],
                        borderWidth: 2,
                        tension: 0.35,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: { min: 0, max: 100, grid: { color: '#1e293b' }, ticks: { color: '#64748b' } },
                        x: { grid: { color: '#1e293b' }, ticks: { color: '#64748b' } }
                    },
                    plugins: { legend: { display: false } }
                }
            });
            setTimeout(loadTrendData, 1000);
        }

        async function loadTrendData() {
            const host = document.getElementById("trend-host-select").value;
            const metric = document.getElementById("trend-metric-select").value;
            const range = document.getElementById("trend-range-select").value;
            
            if (!host) return;

            try {
                const res = await axios.get(`/api/trends/${host}?metric=${metric}&range=${range}`);
                const data = res.data;

                const labels = data.map(item => item.timestamp.split(' ')[1] || item.timestamp);
                const values = data.map(item => item.value);

                myChart.data.labels = labels;
                myChart.data.datasets[0].data = values;
                myChart.data.datasets[0].label = `${host} - ${metric}`;
                myChart.update();
            } catch (e) {}
        }
    </script>
</body>
</html>
"""

# -------------------------------------------------------------
# 4. MODULES - MONITORING & ALERTS ENGINE
# -------------------------------------------------------------

FILES["modules/api/__init__.py"] = ""

FILES["modules/api/routes.py"] = """from flask import Blueprint, request, jsonify
from core.database import get_db
from core.config import Config
from modules.alert_engine.lifecycle import evaluate_alerts
import pymysql
import json

api_bp = Blueprint('api_bp', __name__)

def require_api_key(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        key = request.headers.get('X-API-Key')
        if not key or key != Config.API_KEY:
            return jsonify({"status": "error", "message": "Unauthorized API Key validation failed."}), 401
        return f(*args, **kwargs)
    return decorated

@api_bp.route('/report', methods=['POST'])
@require_api_key
def report_metrics():
    data = request.get_json() or {}
    hostname = data.get('hostname')
    if not hostname:
        return jsonify({"status": "error", "message": "Hostname is required."}), 400

    ip_address = data.get('ip_address', '')
    os_platform = data.get('os_platform', 'Linux')
    agent_version = data.get('agent_version', '1.1.0')
    cpu = float(data.get('cpu_percent', 0.0))
    ram = float(data.get('memory_percent', 0.0))
    disk = float(data.get('disk_percent', 0.0))
    rx = float(data.get('network_rx', 0.0))
    tx = float(data.get('network_tx', 0.0))
    services_status = data.get('services_status', {})
    group_id = data.get('group_id')

    conn = get_db()
    try:
        with conn.cursor() as cursor:
            # Upsert host metrics
            cursor.execute(\"\"\"
            INSERT INTO hosts (hostname, ip_address, last_seen, os_platform, agent_version, group_id, status)
            VALUES (%s, %s, NOW(), %s, %s, %s, 'UP')
            ON DUPLICATE KEY UPDATE
                ip_address = VALUES(ip_address),
                last_seen = NOW(),
                os_platform = VALUES(os_platform),
                agent_version = VALUES(agent_version),
                group_id = COALESCE(VALUES(group_id), group_id),
                status = 'UP'
            \"\"\", (hostname, ip_address, os_platform, agent_version, group_id))

            # Retrieve host identity ID
            cursor.execute("SELECT id FROM hosts WHERE hostname = %s", (hostname,))
            host_id = cursor.fetchone()['id']

            # Insert raw metrics logs
            srv_str = json.dumps(services_status)
            cursor.execute(\"\"\"
            INSERT INTO metrics (host_id, cpu_percent, memory_percent, disk_percent, network_rx, network_tx, services_status)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            \"\"\", (host_id, cpu, ram, disk, rx, tx, srv_str))

        conn.commit()

        # Run alerts evaluator
        metrics_payload = {
            "cpu_percent": cpu,
            "memory_percent": ram,
            "disk_percent": disk,
            "network_rx": rx,
            "network_tx": tx
        }
        evaluate_alerts(host_id, hostname, metrics_payload)

        return jsonify({"status": "success", "message": "Metrics reported successfully."})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@api_bp.route('/events', methods=['POST'])
@require_api_key
def report_event():
    data = request.get_json() or {}
    hostname = data.get('hostname')
    event_type = data.get('event_type', 'GENERAL')
    message = data.get('message', '')
    severity = data.get('severity', 'INFO')

    if not hostname or not message:
        return jsonify({"status": "error", "message": "Required fields hostname and message."}), 400

    conn = get_db()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT id FROM hosts WHERE hostname = %s", (hostname,))
            host = cursor.fetchone()
            if not host:
                return jsonify({"status": "error", "message": "Host node is not registered."}), 404
            host_id = host['id']

            cursor.execute(\"\"\"
            INSERT INTO events (host_id, event_type, message, severity)
            VALUES (%s, %s, %s, %s)
            \"\"\", (host_id, event_type, message, severity))
        conn.commit()
        return jsonify({"status": "success", "message": "Event recorded."})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@api_bp.route('/latest', methods=['GET'])
def latest_metrics():
    group_id = request.args.get('group_id')
    status = request.args.get('status')

    conn = get_db()
    try:
        with conn.cursor(pymysql.cursors.DictCursor) as cursor:
            query = \"\"\"
            SELECT h.*, m.cpu_percent, m.memory_percent, m.disk_percent, m.network_rx, m.network_tx, m.services_status, m.timestamp as metrics_timestamp
            FROM hosts h
            LEFT JOIN (
                SELECT m1.* FROM metrics m1
                INNER JOIN (
                    SELECT host_id, MAX(id) as max_id FROM metrics GROUP BY host_id
                ) m2 ON m1.id = m2.max_id
            ) m ON h.id = m.host_id
            WHERE 1=1
            \"\"\"
            params = []
            if group_id:
                query += " AND h.group_id = %s"
                params.append(group_id)
            if status:
                query += " AND h.status = %s"
                params.append(status)

            cursor.execute(query, params)
            hosts = cursor.fetchall()
            
            # Format datetime strings to ensure valid JSON transfers
            for h in hosts:
                if h['last_seen']:
                    h['last_seen'] = h['last_seen'].strftime('%Y-%m-%d %H:%M:%S')
                if h['metrics_timestamp']:
                    h['metrics_timestamp'] = h['metrics_timestamp'].strftime('%Y-%m-%d %H:%M:%S')

            return jsonify(hosts)
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@api_bp.route('/trends/<hostname>', methods=['GET'])
def metrics_trends(hostname):
    metric_name = request.args.get('metric', 'cpu_percent')
    time_range = request.args.get('range', '1h')

    range_mappings = {
        "1h": "INTERVAL 1 HOUR",
        "6h": "INTERVAL 6 HOUR",
        "24h": "INTERVAL 24 HOUR"
    }
    interval = range_mappings.get(time_range, "INTERVAL 1 HOUR")

    if metric_name not in ['cpu_percent', 'memory_percent', 'disk_percent', 'network_rx', 'network_tx']:
        return jsonify({"status": "error", "message": "Invalid metric parameter."}), 400

    conn = get_db()
    try:
        with conn.cursor(pymysql.cursors.DictCursor) as cursor:
            query = f\"\"\"
            SELECT m.timestamp, m.{metric_name} as value
            FROM metrics m
            JOIN hosts h ON m.host_id = h.id
            WHERE h.hostname = %s AND m.timestamp >= NOW() - {interval}
            ORDER BY m.timestamp ASC
            \"\"\"
            cursor.execute(query, (hostname,))
            trends = cursor.fetchall()
            for t in trends:
                if t['timestamp']:
                    t['timestamp'] = t['timestamp'].strftime('%Y-%m-%d %H:%M:%S')
            return jsonify(trends)
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@api_bp.route('/alerts', methods=['GET'])
def list_alerts():
    status = request.args.get('status')
    hostname = request.args.get('hostname')

    conn = get_db()
    try:
        with conn.cursor(pymysql.cursors.DictCursor) as cursor:
            query = \"\"\"
            SELECT a.*, h.hostname, r.name as rule_name, r.metric_name
            FROM alerts a
            JOIN hosts h ON a.host_id = h.id
            JOIN alert_rules r ON a.rule_id = r.id
            WHERE 1=1
            \"\"\"
            params = []
            if status:
                query += " AND a.status = %s"
                params.append(status)
            if hostname:
                query += " AND h.hostname = %s"
                params.append(hostname)

            query += " ORDER BY a.triggered_at DESC"
            cursor.execute(query, params)
            alerts = cursor.fetchall()

            for a in alerts:
                if a['triggered_at']:
                    a['triggered_at'] = a['triggered_at'].strftime('%Y-%m-%d %H:%M:%S')
                if a['acknowledged_at']:
                    a['acknowledged_at'] = a['acknowledged_at'].strftime('%Y-%m-%d %H:%M:%S')
                if a['resolved_at']:
                    a['resolved_at'] = a['resolved_at'].strftime('%Y-%m-%d %H:%M:%S')

            return jsonify(alerts)
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@api_bp.route('/alerts/<int:alert_id>/acknowledge', methods=['POST'])
def acknowledge_alert(alert_id):
    conn = get_db()
    try:
        with conn.cursor() as cursor:
            cursor.execute("UPDATE alerts SET status = 'ACKNOWLEDGED', acknowledged_at = NOW() WHERE id = %s", (alert_id,))
        conn.commit()
        return jsonify({"status": "success", "message": "Alert state acknowledged."})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@api_bp.route('/groups', methods=['GET', 'POST'])
def manage_groups():
    conn = get_db()
    if request.method == 'GET':
        try:
            with conn.cursor(pymysql.cursors.DictCursor) as cursor:
                cursor.execute("SELECT * FROM host_groups")
                return jsonify(cursor.fetchall())
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500

    if request.method == 'POST':
        data = request.get_json() or {}
        name = data.get('name')
        desc = data.get('description', '')
        if not name:
            return jsonify({"status": "error", "message": "Group identity is missing."}), 400

        try:
            with conn.cursor() as cursor:
                cursor.execute("INSERT INTO host_groups (name, description) VALUES (%s, %s)", (name, desc))
            conn.commit()
            return jsonify({"status": "success", "message": f"Group {name} spawned."})
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500

@api_bp.route('/summary', methods=['GET'])
def system_summary():
    conn = get_db()
    try:
        with conn.cursor(pymysql.cursors.DictCursor) as cursor:
            cursor.execute("SELECT COUNT(*) as total FROM hosts")
            total = cursor.fetchone()['total']

            cursor.execute("SELECT COUNT(*) as up FROM hosts WHERE status = 'UP'")
            up = cursor.fetchone()['up']

            cursor.execute("SELECT COUNT(*) as warning FROM hosts WHERE status = 'WARNING'")
            warn = cursor.fetchone()['warning']

            cursor.execute("SELECT COUNT(*) as down FROM hosts WHERE status = 'DOWN'")
            down = cursor.fetchone()['down']

            cursor.execute("SELECT COUNT(*) as active_alerts FROM alerts WHERE status IN ('OPEN', 'ACKNOWLEDGED')")
            active_alerts = cursor.fetchone()['active_alerts']

            return jsonify({
                "total_hosts": total,
                "up_hosts": up,
                "warning_hosts": warn,
                "down_hosts": down,
                "active_alerts": active_alerts
            })
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@api_bp.route('/rules', methods=['GET', 'POST'])
def manage_rules():
    conn = get_db()
    if request.method == 'GET':
        try:
            with conn.cursor(pymysql.cursors.DictCursor) as cursor:
                cursor.execute("SELECT * FROM alert_rules")
                return jsonify(cursor.fetchall())
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500

    if request.method == 'POST':
        data = request.get_json() or {}
        name = data.get('name')
        metric = data.get('metric_name')
        op = data.get('operator')
        threshold = float(data.get('threshold', 0))
        template = data.get('email_template', '')

        if not name or not metric or not op:
            return jsonify({"status": "error", "message": "Missing required validation rules."}), 400

        try:
            with conn.cursor() as cursor:
                cursor.execute(\"\"\"
                INSERT INTO alert_rules (name, metric_name, operator, threshold, email_template)
                VALUES (%s, %s, %s, %s, %s)
                \"\"\", (name, metric, op, threshold, template))
            conn.commit()
            return jsonify({"status": "success", "message": f"Rule {name} added."})
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500

@api_bp.route('/rules/<int:rule_id>/toggle', methods=['POST'])
def toggle_rule(rule_id):
    conn = get_db()
    try:
        with conn.cursor(pymysql.cursors.DictCursor) as cursor:
            cursor.execute("SELECT is_enabled FROM alert_rules WHERE id = %s", (rule_id,))
            rule = cursor.fetchone()
            if not rule:
                return jsonify({"status": "error", "message": "Rule target not found."}), 404
            new_state = 0 if rule['is_enabled'] else 1
            cursor.execute("UPDATE alert_rules SET is_enabled = %s WHERE id = %s", (new_state, rule_id))
        conn.commit()
        return jsonify({"status": "success", "message": f"Rule state shifted to {new_state}."})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@api_bp.route('/rules/<int:rule_id>', methods=['DELETE'])
def delete_rule(rule_id):
    conn = get_db()
    try:
        with conn.cursor() as cursor:
            cursor.execute("DELETE FROM alert_rules WHERE id = %s", (rule_id,))
        conn.commit()
        return jsonify({"status": "success", "message": "Rule wiped."})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@api_bp.route('/hosts', methods=['GET', 'POST'])
def manage_hosts():
    conn = get_db()
    if request.method == 'GET':
        try:
            with conn.cursor(pymysql.cursors.DictCursor) as cursor:
                cursor.execute("SELECT * FROM hosts")
                return jsonify(cursor.fetchall())
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500

    if request.method == 'POST':
        data = request.get_json() or {}
        hostname = data.get('hostname')
        ip_address = data.get('ip_address', '')
        os_platform = data.get('os_platform', 'Linux')
        group_id = data.get('group_id')

        if not hostname:
            return jsonify({"status": "error", "message": "Missing node hostname identifiers."}), 400

        try:
            with conn.cursor() as cursor:
                cursor.execute(\"\"\"
                INSERT INTO hosts (hostname, ip_address, os_platform, status, last_seen, group_id)
                VALUES (%s, %s, %s, 'UP', NOW(), %s)
                \"\"\", (hostname, ip_address, os_platform, group_id))
            conn.commit()
            return jsonify({"status": "success", "message": f"Node {hostname} instantiated."})
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)}), 500

import threading
import subprocess

discovery_state = {
    "is_running": False,
    "progress": 0,
    "total_ips": 0,
    "found_hosts": []
}

def ping_sweep():
    global discovery_state
    discovery_state["is_running"] = True
    discovery_state["progress"] = 0
    discovery_state["found_hosts"] = []

    subnet = Config.DISCOVERY_SUBNET
    base_ip = ".".join(subnet.split("/")[0].split(".")[:3]) + "."
    ips = [f"{base_ip}{i}" for i in range(1, 255)]
    discovery_state["total_ips"] = len(ips)

    import concurrent.futures
    def ping_host(ip):
        try:
            param = '-n' if subprocess.os.name == 'nt' else '-c'
            # Quick 1 packet ping command with 1s timeouts
            cmd = ['ping', param, '1', '-W', '1', ip]
            res = subprocess.call(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if res == 0:
                return ip
        except Exception:
            pass
        return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
        for idx, ip in enumerate(executor.map(ping_host, ips)):
            discovery_state["progress"] = int(((idx + 1) / len(ips)) * 100)
            if ip:
                discovery_state["found_hosts"].append(ip)
                conn = get_db()
                try:
                    with conn.cursor() as cursor:
                        hostname = f"discovered_node_{ip.replace('.', '_')}"
                        cursor.execute(\"\"\"
                        INSERT IGNORE INTO hosts (hostname, ip_address, last_seen, os_platform, status)
                        VALUES (%s, %s, NOW(), 'Discovered Node', 'UP')
                        \"\"\", (hostname, ip))
                    conn.commit()
                except Exception:
                    pass

    discovery_state["is_running"] = False

@api_bp.route('/discover/start', methods=['POST'])
def start_discover():
    if discovery_state["is_running"]:
        return jsonify({"status": "error", "message": "Auto discovery block: Run active."}), 400
    
    t = threading.Thread(target=ping_sweep)
    t.daemon = True
    t.start()
    return jsonify({"status": "success", "message": "Discovery thread spawned."})

@api_bp.route('/discover/status', methods=['GET'])
def get_discover_status():
    return jsonify(discovery_state)

@api_bp.route('/ai_insights', methods=['GET'])
def get_ai_insights():
    conn = get_db()
    try:
        with conn.cursor(pymysql.cursors.DictCursor) as cursor:
            cursor.execute(\"\"\"
            SELECT ai.*, h.hostname
            FROM ai_insights ai
            LEFT JOIN hosts h ON ai.host_id = h.id
            ORDER BY ai.generated_at DESC
            \"\"\")
            res = cursor.fetchall()
            for r in res:
                if r['generated_at']:
                    r['generated_at'] = r['generated_at'].strftime('%Y-%m-%d %H:%M:%S')
            return jsonify(res)
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
"""

FILES["modules/monitoring_checks/__init__.py"] = ""

FILES["modules/monitoring_checks/status_updater.py"] = """from core.database import get_db
import logging

def compute_status():
    conn = get_db()
    try:
        with conn.cursor() as cursor:
            # Shift host status node to DOWN after 120s of silence
            cursor.execute(\"\"\"
            UPDATE hosts 
            SET status = 'DOWN' 
            WHERE last_seen IS NOT NULL AND last_seen < NOW() - INTERVAL 120 SECOND AND status != 'DOWN'
            \"\"\")
            
            # Shift status to WARNING after 60s of silence
            cursor.execute(\"\"\"
            UPDATE hosts 
            SET status = 'WARNING' 
            WHERE last_seen IS NOT NULL AND last_seen < NOW() - INTERVAL 60 SECOND AND last_seen >= NOW() - INTERVAL 120 SECOND AND status != 'WARNING'
            \"\"\")
        conn.commit()
    except Exception as e:
        logging.error(f"Failed to process host monitoring statuses: {e}")
"""

FILES["modules/monitoring_checks/ssl_expiry.py"] = """import socket
import ssl
from datetime import datetime
from core.database import get_db
import logging

def get_ssl_expiry(domain, port=443):
    try:
        context = ssl.create_default_context()
        with socket.create_connection((domain, port), timeout=5) as sock:
            with context.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
                expiry_str = cert['notAfter']
                return datetime.strptime(expiry_str, '%b %d %H:%M:%S %Y %Z')
    except Exception as e:
        logging.error(f"Failed to check SSL for {domain}: {e}")
        return None

def check_all_certificates():
    conn = get_db()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT id, domain, host_id FROM ssl_certificates")
            certs = cursor.fetchall()
            
            for cert in certs:
                expiry = get_ssl_expiry(cert['domain'])
                if expiry:
                    status = 'VALID'
                    days_left = (expiry - datetime.now()).days
                    if days_left <= 0:
                        status = 'EXPIRED'
                    elif days_left <= 7:
                        status = 'CRITICAL'
                    elif days_left <= 30:
                        status = 'WARNING'
                        
                    cursor.execute(\"\"\"
                    UPDATE ssl_certificates 
                    SET expiry_date = %s, status = %s, last_checked = NOW()
                    WHERE id = %s
                    \"\"\", (expiry, status, cert['id']))
        conn.commit()
    except Exception as e:
        logging.error(f"Error checking SSL certificates expiry boundaries: {e}")
"""

FILES["modules/alert_engine/__init__.py"] = ""

FILES["modules/alert_engine/lifecycle.py"] = """from core.database import get_db
from modules.alert_engine.notifiers import send_email, send_teams_alert
import logging

def evaluate_alerts(host_id, hostname, metrics):
    conn = get_db()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM alert_rules WHERE is_enabled = 1")
            rules = cursor.fetchall()
            
            for rule in rules:
                metric_name = rule['metric_name']
                operator = rule['operator']
                threshold = rule['threshold']
                
                if metric_name not in metrics:
                    continue
                    
                val = float(metrics[metric_name])
                breached = False
                
                if operator == '>' and val > threshold:
                    breached = True
                elif operator == '<' and val < threshold:
                    breached = True
                elif operator == '==' and val == threshold:
                    breached = True
                    
                if breached:
                    # Check if incident is already OPEN
                    cursor.execute(\"\"\"
                    SELECT id FROM alerts 
                    WHERE host_id = %s AND rule_id = %s AND status IN ('OPEN', 'ACKNOWLEDGED')
                    \"\"\", (host_id, rule['id']))
                    existing = cursor.fetchone()
                    
                    if not existing:
                        msg = rule['email_template'].format(hostname=hostname, value=val)
                        cursor.execute(\"\"\"
                        INSERT INTO alerts (host_id, rule_id, status, triggered_at, value, message)
                        VALUES (%s, %s, 'OPEN', NOW(), %s, %s)
                        \"\"\", (host_id, rule['id'], val, msg))
                        conn.commit()
                        
                        # Dispatch notifications
                        sub = f"SysWatch Alert: {rule['name']} breached on {hostname}"
                        body = f"Host: {hostname}\\nRule: {rule['name']}\\nMetric Value: {val}\\nNarrative: {msg}"
                        send_email(sub, body)
                        send_teams_alert(sub, body)
    except Exception as e:
        logging.error(f"Alert lifecycle validation pipeline failed: {e}")
"""

FILES["modules/alert_engine/auto_resolve.py"] = """from core.database import get_db
import logging

def auto_resolve_stale_alerts():
    conn = get_db()
    try:
        with conn.cursor() as cursor:
            # Query alerts currently raised
            cursor.execute(\"\"\"
            SELECT a.id, a.host_id, a.rule_id, h.hostname, r.metric_name, r.operator, r.threshold
            FROM alerts a
            JOIN hosts h ON a.host_id = h.id
            JOIN alert_rules r ON a.rule_id = r.id
            WHERE a.status IN ('OPEN', 'ACKNOWLEDGED')
            \"\"\")
            alerts = cursor.fetchall()
            
            for alert in alerts:
                # Query most recent metric report for the host
                cursor.execute(\"\"\"
                SELECT * FROM metrics 
                WHERE host_id = %s 
                ORDER BY id DESC LIMIT 1
                \"\"\", (alert['host_id'],))
                metric_rec = cursor.fetchone()
                
                if not metric_rec:
                    continue
                    
                metric_name = alert['metric_name']
                operator = alert['operator']
                threshold = alert['threshold']
                
                if metric_name not in metric_rec:
                    continue
                    
                val = float(metric_rec[metric_name])
                resolved = False
                
                # Reverse boolean matching logic
                if operator == '>' and val <= threshold:
                    resolved = True
                elif operator == '<' and val >= threshold:
                    resolved = True
                elif operator == '==' and val != threshold:
                    resolved = True
                    
                if resolved:
                    cursor.execute(\"\"\"
                    UPDATE alerts 
                    SET status = 'RESOLVED', resolved_at = NOW() 
                    WHERE id = %s
                    \"\"\", (alert['id'],))
                    logging.info(f"Auto-resolution verified alert ID {alert['id']} for {alert['hostname']}.")
        conn.commit()
    except Exception as e:
        logging.error(f"Alert engine auto-resolution loop encountered errors: {e}")
"""

FILES["modules/alert_engine/notifiers.py"] = """import smtplib
from email.mime.text import MIMEText
import requests
from core.config import Config
import logging

def send_email(subject, body, to_email=None):
    if not Config.SMTP_USER or not Config.SMTP_PASSWORD:
        logging.info("SMTP credentials incomplete. Skipping email alerting.")
        return False
    try:
        recipient = to_email or Config.SMTP_USER
        msg = MIMEText(body)
        msg['Subject'] = subject
        msg['From'] = Config.SMTP_USER
        msg['To'] = recipient

        with smtplib.SMTP(Config.SMTP_SERVER, Config.SMTP_PORT) as server:
            server.starttls()
            server.login(Config.SMTP_USER, Config.SMTP_PASSWORD)
            server.sendmail(Config.SMTP_USER, recipient, msg.as_string())
        logging.info(f"Alerting email successfully dispatched to {recipient}.")
        return True
    except Exception as e:
        logging.error(f"Failed to route alerting email: {e}")
        return False

def send_teams_alert(title, text):
    if not Config.TEAMS_WEBHOOK_URL:
        logging.info("Teams integration missing. Skipping webhook alerts.")
        return False
    try:
        payload = {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": "E81123",
            "summary": title,
            "sections": [{
                "activityTitle": title,
                "activitySubtitle": "SysWatch Telemetry Alerts Engine",
                "text": text
            }]
        }
        res = requests.post(Config.TEAMS_WEBHOOK_URL, json=payload, timeout=5)
        if res.status_code == 200:
            logging.info("Teams webhook alert successfully routed.")
            return True
    except Exception as e:
        logging.error(f"Failed to route Teams webhook message: {e}")
    return False
"""

# -------------------------------------------------------------
# 5. MODULES - ARTIFICIAL INTELLIGENCE (AI)
# -------------------------------------------------------------

FILES["modules/ai/__init__.py"] = ""

FILES["modules/ai/deepseek.py"] = """import requests
import json
from core.config import Config
import logging

def analyze_with_deepseek(analysis_type, context):
    if not Config.DEEPSEEK_API_KEY:
        logging.info("DeepSeek AI configuration inactive. Swapping to local diagnostic models.")
        return None

    prompts = {
        "root-cause": (
            "Diagnose system metrics and events to solve a critical failure outage.\\n"
            "Return ONLY a clean JSON object with keys 'summary' and 'steps' (array of text strings).\\n\\n"
            f"Context: {json.dumps(context)}"
        ),
        "predictive": (
            "Analyze current disk/ram trends to forecast potential exhaustion events.\\n"
            "Return ONLY a clean JSON object with keys 'exhaustion_forecast' and 'risk_level' (LOW/MEDIUM/HIGH).\\n\\n"
            f"Context: {json.dumps(context)}"
        ),
        "daily_briefing": (
            "Draft a comprehensive daily shift system briefing report in beautiful markdown format.\\n"
            "Return ONLY a clean JSON object with keys 'briefing' and 'critical_warnings_count'.\\n\\n"
            f"Context: {json.dumps(context)}"
        )
    }

    prompt = prompts.get(analysis_type, f"Diagnostics data: {json.dumps(context)}")
    headers = {
        "Authorization": f"Bearer {Config.DEEPSEEK_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": Config.DEEPSEEK_MODEL,
        "messages": [
            {"role": "system", "content": "You are SysWatch DeepSeek AI, a world-class IT operations assistant."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.15
    }

    try:
        res = requests.post(f"{Config.DEEPSEEK_API_URL}/chat/completions", json=payload, headers=headers, timeout=12)
        if res.status_code == 200:
            content = res.json()['choices'][0]['message']['content'].strip()
            # Clean up markdown JSON markers if returned
            if content.startswith("```json"):
                content = content.replace("```json", "", 1).replace("```", "", 1).strip()
            elif content.startswith("```"):
                content = content.replace("```", "", 1).replace("```", "", 1).strip()
            return json.loads(content)
    except Exception as e:
        logging.error(f"DeepSeek connection sequence faulted: {e}")
    return None
"""

FILES["modules/ai/anomaly.py"] = """from core.database import get_db
from modules.ai.deepseek import analyze_with_deepseek
import json
import logging

def run_anomaly_detection():
    conn = get_db()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT id, hostname FROM hosts WHERE status != 'DOWN'")
            hosts = cursor.fetchall()
            
            for host in hosts:
                cursor.execute(\"\"\"
                SELECT cpu_percent, memory_percent FROM metrics 
                WHERE host_id = %s ORDER BY id DESC LIMIT 40
                \"\"\", (host['id'],))
                recs = cursor.fetchall()
                if len(recs) < 8:
                    continue
                
                cpus = [r['cpu_percent'] for r in recs]
                avg = sum(cpus) / len(cpus)
                
                # Compute statistical deviation (Sigma-3)
                var = sum((x - avg) ** 2 for x in cpus) / len(cpus)
                dev = var ** 0.5
                
                if dev > 0 and abs(cpus[0] - avg) > (3 * dev) and cpus[0] > 75:
                    context = {
                        "hostname": host['hostname'],
                        "current_usage": cpus[0],
                        "average_usage": avg,
                        "deviation_sigma": dev
                    }
                    ai = analyze_with_deepseek("root-cause", context)
                    
                    summary = "Sigma-3 metrics deviation anomaly detected."
                    steps = json.dumps(["Monitor host services status", "Run log checks", "Check running tasks"])
                    
                    if ai:
                        summary = ai.get("summary", summary)
                        steps = json.dumps(ai.get("steps", []))
                        
                    cursor.execute(\"\"\"
                    INSERT INTO ai_insights (host_id, insight_type, summary, analysis)
                    VALUES (%s, 'ANOMALY', %s, %s)
                    \"\"\", (host['id'], summary, steps))
        conn.commit()
    except Exception as e:
        logging.error(f"AI operations anomaly pipeline faulted: {e}")

def run_predictions():
    conn = get_db()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT id, hostname FROM hosts WHERE status != 'DOWN'")
            hosts = cursor.fetchall()
            
            for host in hosts:
                cursor.execute(\"\"\"
                SELECT disk_percent FROM metrics 
                WHERE host_id = %s ORDER BY id DESC LIMIT 80
                \"\"\", (host['id'],))
                recs = cursor.fetchall()
                if len(recs) < 10:
                    continue
                    
                disks = [r['disk_percent'] for r in recs]
                is_growing = disks[0] > disks[-1]
                
                if is_growing:
                    context = {
                        "hostname": host['hostname'],
                        "recent_trend": disks[:10]
                    }
                    ai = analyze_with_deepseek("predictive", context)
                    
                    summary = "Capacity metrics forecast warning triggered."
                    risk = "LOW"
                    if ai:
                        summary = ai.get("exhaustion_forecast", summary)
                        risk = ai.get("risk_level", risk)
                        
                    cursor.execute(\"\"\"
                    INSERT INTO ai_insights (host_id, insight_type, summary, analysis)
                    VALUES (%s, 'FORECAST', %s, %s)
                    \"\"\", (host['id'], summary, f"Exhaustion Risk Profile: {risk}"))
        conn.commit()
    except Exception as e:
        logging.error(f"AI capacity prediction loop failed: {e}")

def send_daily_briefing():
    conn = get_db()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT COUNT(*) as count FROM alerts WHERE status IN ('OPEN', 'ACKNOWLEDGED')")
            active_alerts = cursor.fetchone()['count']
            
            cursor.execute("SELECT COUNT(*) as count FROM hosts WHERE status = 'DOWN'")
            down_hosts = cursor.fetchone()['count']
            
            context = {
                "active_incidents": active_alerts,
                "offline_nodes": down_hosts,
                "scope_interval": "Past 24 Hours Operations"
            }
            ai = analyze_with_deepseek("daily_briefing", context)
            
            briefing = "### Daily Shifts Briefing\\nAll services are within standard parameters. No major outages resolved today."
            if ai:
                briefing = ai.get("briefing", briefing)
                
            cursor.execute(\"\"\"
            INSERT INTO ai_insights (host_id, insight_type, summary, analysis)
            VALUES (NULL, 'DAILY_BRIEF', 'Administrative Daily Operational Brief', %s)
            \"\"\", (briefing,))
        conn.commit()
    except Exception as e:
        logging.error(f"Daily system briefings compile failed: {e}")
"""

# -------------------------------------------------------------
# 6. CLIENT MONITORING AGENT
# -------------------------------------------------------------

FILES["agents/__init__.py"] = ""

FILES["agents/client.py"] = """import os
import sys
import time
import socket
import requests
import psutil
from dotenv import load_dotenv

load_dotenv()

SERVER_URL = os.getenv("SERVER_URL", "http://127.0.0.1:3000")
API_KEY = os.getenv("API_KEY", "syswatch_agent_api_key_xyz_9988")
GROUP_ID = os.getenv("GROUP_ID", None)

def collect_metrics():
    # Gather CPU utilization
    cpu = psutil.cpu_percent(interval=None)
    # Gather RAM usage
    ram = psutil.virtual_memory().percent
    # Gather main disk capacity usage
    disk = psutil.disk_usage('/').percent

    # Gather system network statistics
    net_before = psutil.net_io_counters()
    time.sleep(0.5)
    net_after = psutil.net_io_counters()
    
    rx = (net_after.bytes_recv - net_before.bytes_recv) / 1024.0 # KB/s
    tx = (net_after.bytes_sent - net_before.bytes_sent) / 1024.0 # KB/s

    # Service health status monitoring (Web, SSH, MySQL, etc.)
    services = {}
    for proc in psutil.process_iter(['name']):
        try:
            name = proc.info['name'].lower()
            if 'nginx' in name or 'apache' in name or 'httpd' in name:
                services['web_server'] = 'RUNNING'
            if 'mysqld' in name or 'mariadb' in name:
                services['database'] = 'RUNNING'
            if 'sshd' in name:
                services['ssh'] = 'RUNNING'
        except Exception:
            pass

    return {
        "hostname": socket.gethostname(),
        "ip_address": socket.gethostbyname(socket.gethostname()),
        "os_platform": sys.platform,
        "agent_version": "1.1.0",
        "cpu_percent": cpu,
        "memory_percent": ram,
        "disk_percent": disk,
        "network_rx": rx,
        "network_tx": tx,
        "services_status": services,
        "group_id": GROUP_ID
    }

def send_payload(endpoint, data):
    headers = {
        "X-API-Key": API_KEY,
        "Content-Type": "application/json"
    }
    try:
        url = f"{SERVER_URL.rstrip('/')}{endpoint}"
        res = requests.post(url, json=data, headers=headers, timeout=5)
        return res.status_code == 200
    except Exception as e:
        print(f"Failed to transmit data payload to server: {e}")
        return False

def main():
    print("SysWatch Client Agent v1.1.0 initiated. Tracking telemetry loops...")
    
    # Store unique local host file configuration IDs
    agent_id_file = "agent_id"
    if not os.path.exists(agent_id_file):
        import uuid
        with open(agent_id_file, "w") as f:
            f.write(str(uuid.uuid4()))

    while True:
        payload = collect_metrics()
        success = send_payload("/api/report", payload)
        if success:
            print("Telemetry reporting transmission successful.")
        time.sleep(55) # Transmit metrics reports every 60s

if __name__ == "__main__":
    main()
"""

# -------------------------------------------------------------
# 7. INSTALLERS & CONFIGURATIONS
# -------------------------------------------------------------

FILES["install.sh"] = """#!/bin/bash
# SysWatch v1.1.0 - Production Unix Installation Script
# ====================================================

set -e

echo "=== Initiating SysWatch v1.1.0 Installation ==="
echo "Verifying root administrative execution..."

if [ "$EUID" -ne 0 ]; then
  echo "Please execute this script using administrative sudo privileges."
  exit 1
fi

# 1. Distro Detection
if [ -f /etc/debian_version ]; then
    PKG_MAN="apt-get"
    $PKG_MAN update -y
    $PKG_MAN install -y python3 python3-venv python3-pip mariadb-server nginx git curl
elif [ -f /etc/redhat-release ]; then
    PKG_MAN="dnf"
    $PKG_MAN install -y python3 python3-pip mariadb-server nginx git curl
else
    echo "Unsupported distribution OS platform. Exiting."
    exit 1
fi

# 2. Database configuration setups
echo "Configuring MySQL service units..."
systemctl start mariadb || systemctl start mysql
systemctl enable mariadb || systemctl enable mysql

echo "Building virtualenvs & pip requirements installation..."
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 3. Setting system variables
if [ ! -f .env ]; then
  cp .env.example .env
  echo "Spawned standard production .env configuration file."
fi

# 4. Systemd integrations
echo "Configuring daemon systemd service..."
cat <<EOF > /etc/systemd/system/syswatch.service
[Unit]
Description=SysWatch Monitoring Core Daemon
After=network.target mariadb.service

[Service]
User=root
WorkingDirectory=$(pwd)
ExecStart=$(pwd)/venv/bin/gunicorn -w 4 -b 0.0.0.0:3000 wsgi:app
Restart=always

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl start syswatch
systemctl enable syswatch

echo "=== SysWatch v1.1.0 Installation Completed Successfully ==="
echo "The system is accessible on http://localhost:3000"
"""

FILES["install.ps1"] = """# SysWatch v1.1.0 Windows Setup & Deployment
# ==========================================

Write-Host "=== Initiating SysWatch Windows Installation ===" -ForegroundColor Blue

# Verify administrative authority
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Warning "Administrative privilege checks failed. Rerun as Administrator."
    Exit
}

# Install Chocolatey packages if missing
if (-not (Get-Command chco -ErrorAction SilentlyContinue)) {
    Write-Host "Installing Chocolatey manager packages..."
    Set-ExecutionPolicy Bypass -Scope Process -Force
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
    Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
}

# Installs dependencies
Write-Host "Installing Python & MySQL utilities..."
choco install python mysql -y

# Unpacks environment packages
Write-Host "Building Python runtime environments..."
python -m venv venv
& .\\venv\\Scripts\\Activate.ps1
pip install -r requirements.txt

if (-not (Test-Path .env)) {
    Copy-Item .env.example .env
}

# Setup scheduled system startup tasks
Write-Host "Configuring system startup schedules..."
$action = New-ScheduledTaskAction -Execute 'python.exe' -Argument 'wsgi.py' -WorkingDirectory (Get-Location).Path
$trigger = New-ScheduledTaskTrigger -AtStartup
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -TaskName "SysWatchService" -Action $action -Trigger $trigger -Settings $settings -User "NT AUTHORITY\\SYSTEM" -Force

Write-Host "=== SysWatch Installation Succeeded ===" -ForegroundColor Green
"""

FILES["wsgi.py"] = """from core.app import create_app

app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000)
"""

FILES["requirements.txt"] = """flask>=3.0.0
flask-login>=0.6.3
pymysql>=1.1.0
python-dotenv>=1.0.0
requests>=2.31.0
psutil>=5.9.8
gunicorn>=21.2.0
apscheduler>=3.10.4
pyOpenSSL>=24.0.0
"""

FILES["README.md"] = """# SysWatch v1.1.0

SysWatch is an open‑source, enterprise-ready infrastructure monitoring platform designed for system administrators. It integrates real‑time metrics collection, event auditing, automated alerts, and advanced AI predictions/anomalies in a single, lightweight package.

## Features
- **Real-Time Dashboards**: Beautiful, unified single-page monitoring interface.
- **Cross-Platform Client Agent**: Lightweight Python daemon for CPU, RAM, Disk, active services, package updates, and logon events.
- **Alert Lifecycle Engine**: Threshold triggers with manual/automatic resolution and SMTP/Microsoft Teams integrations.
- **DeepSeek AI Integration**: Automated root-cause troubleshooting analysis, trend forecasting, and daily administrative briefs.
- **Host Discovery**: Multithreaded subnetwork ping sweeps to discover active network nodes.
- **One-Click Deployments**: Fully productionized automated Linux shell installers and Windows PowerShell setup.

## Quick Start
1. Run `python build_syswatch.py` to unpack the directory structure.
2. Edit `.env` to configure your credentials and API keys.
3. Launch with `python wsgi.py` or run `install.sh` / `install.ps1`.
"""

FILES["LICENSE.txt"] = """MIT License

Copyright (c) 2026 SysWatch Team

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

FILES[".env.example"] = """# SysWatch Configuration Example
SECRET_KEY=generate_a_random_secure_key_here
API_KEY=syswatch_agent_api_key_xyz_9988

# MySQL Database Configuration
DB_HOST=127.0.0.1
DB_USER=syswatch
DB_PASSWORD=syswatch_secure_password
DB_NAME=syswatch_db

# Admin User Initialization
ADMIN_USER=admin
ADMIN_PASSWORD=sysadmin_password_change_me

# SMTP Notifications
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=alerts@example.com
SMTP_PASSWORD=smtp_app_password

# MS Teams Integration
TEAMS_WEBHOOK_URL=https://outlook.office.com/webhook/placeholder

# Discovery Configuration
DISCOVERY_SUBNET=192.168.1.0/24

# DeepSeek AI Integration
DEEPSEEK_API_KEY=your_deepseek_api_key_here
DEEPSEEK_API_URL=https://api.deepseek.com/v1
DEEPSEEK_MODEL=deepseek-chat
"""

FILES[".gitignore"] = """*.pyc
__pycache__/
.env
venv/
*.log
agent_id
syswatch_db.sql
dist/
build/
"""


def main():
    target_dir = "syswatch_v1.1.0"
    print(f"Creating project directory structure inside '{target_dir}'...")
    
    # Iterate and construct paths
    for rel_path, file_content in FILES.items():
        full_path = os.path.join(target_dir, rel_path)
        dir_name = os.path.dirname(full_path)
        
        # Spawn directory structures
        if dir_name and not os.path.exists(dir_name):
            os.makedirs(dir_name, exist_ok=True)
            
        # Write files byte-for-byte or encoded characters
        with open(full_path, "w", encoding="utf-8") as file_handle:
            file_handle.write(file_content)
            
        print(f" -> Created file: {rel_path}")

    # Set execution bit permissions for Linux installers
    sh_path = os.path.join(target_dir, "install.sh")
    if os.path.exists(sh_path):
        try:
            st = os.stat(sh_path)
            os.chmod(sh_path, st.st_mode | stat.S_IEXEC)
            print(" -> Made install.sh script executable.")
        except Exception:
            pass

    print("\\n=======================================================")
    print("  SysWatch v1.1.0 Project Generated Successfully! ")
    print(f"  Target Folder: {target_dir}")
    print("=======================================================\\n")

if __name__ == "__main__":
    main()
